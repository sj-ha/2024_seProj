package com.calc;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

// JUnit 테스트
// main은 테스트를 잘 하지 않으나, main에 실행 코드가 있을 경우 테스트 진행해야 한다. 또한 메소드 앞 private일 경우에도 테스트 진행하지 않는다.(*그 이유는 어딘가에서 실행이 됐을 수도 있기 때문.)ㄴ


class CalculatorTest {

	Calculator c = new Calculator();
	
	@Test
	void testAdd() {
//		fail("Not yet implemented");
		assertEquals(6, c.add(2, 4));
	}

	@Test
	void testMinus() {
//		fail("Not yet implemented");
		assertEquals(3, c.minus(5, 2));
	}

	@Test
	void testMulti() {
//		fail("Not yet implemented");
		assertEquals(25, c.multi(5, 5));
	}

	@Test
	void testDivide() throws Exception {
//		fail("Not yet implemented");
		assertEquals(2, c.divide(6, 3));
		assertThrows(Exception.class, () -> c.divide(6, 0), "Divide Error");
	}
	
	@Test
	void testCalculate() throws Exception {
//		fail("Not yet implemented");
		assertEquals(8, c.calculate("+", 3, 5));
		assertEquals(2, c.calculate("-", 5, 3));
		assertEquals(15, c.calculate("*", 3, 5));
		assertEquals(2, c.calculate("/", 6, 3));
		assertThrows(Exception.class, () -> c.calculate("^", 3, 6), "Unsupported Operator");
	}
	
	@Test
	void testParseInput() throws Exception {
//		fail("Not yet implemented");
		String[] str = c.parseInput("2 + 3");
//		assertArrayEquals(new String[](), null);
//		assertEquals("3+3", c.parseInput("3+3"));
		assertThrows(Exception.class, () -> c.parseInput("3"), "Invalid Input Format");
	}
}
