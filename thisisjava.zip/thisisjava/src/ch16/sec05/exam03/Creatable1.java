package ch16.sec05.exam03;

@FunctionalInterface
public interface Creatable1 {
	public Member create(String id);
}
