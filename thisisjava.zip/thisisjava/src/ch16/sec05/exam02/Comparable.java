package ch16.sec05.exam02;

@FunctionalInterface
public interface Comparable {
	int compare(String a, String b);
}

