package ch16.sec05.exam01;

@FunctionalInterface
public interface Calcuable {
	double calc(double x, double y);
}

