package ch16.sec01;

public class LambdaExample {
	public static void main(String[] args) {
		Calculable sum = (x, y) -> System.out.println(x + y);
		sum.calculate(20, 10);
		Calculable sub = (x, y) -> System.out.println(x - y);
		sub.calculate(40, 30);

		action((x, y) -> {
			int result = x + y;
			System.out.println("result: " + result);
		});

		action((x, y) -> {
			int result = x - y;
			System.out.println("result: " + result);
		});
	}

	public static void action(Calculable calculable) {
		// 데이터
		int x = 10;
		int y = 4;
		// 데이터 처리
		calculable.calculate(x, y);
	}
}
