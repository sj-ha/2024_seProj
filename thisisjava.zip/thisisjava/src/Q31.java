
public class Q31 {

	public static void main(String[] args) {
		int o = 0, e = 0, cnt;
		String ans = "149854322124";
		for (int i = 0; i < ans.length( ); i++) {
			if (Character.getNumericValue(ans.charAt(i)) % 2 == 1) {
				o++;
			} else {
				e++;
			}
		}
		cnt = e - o;
		System.out.printf("%d", cnt);
	}

}
