
public class Q18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 0, hap = 0;
		for (i = 1; i <= 5; ++i, hap += i) {
			System.out.printf("합은%d %4d입니다.", i, hap);
		}
	}

}
