
// pow(a, b) > a의 b승을 뜻한다.

public class Q36 {

	public static void main(String[] args) {
		int s, t, cnt = 0;
		int test[] = new int[5];
		for (int i = 0; i < 10; i++) {
			s = (int)Math.pow(i, 2);
			t = (s % 10);
			
			try {
				test[t] = i;
			} catch (ArrayIndexOutOfBoundsException e) {
				cnt++;
			}
		}
		System.out.println(cnt);
	}

}
