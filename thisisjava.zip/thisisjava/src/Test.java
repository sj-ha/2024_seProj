
public class Test {

	public static void main(String[] args) {
//		cmd명령어 > java Test 사과 배 감 귤 포도 딸기
		int i = 10;
		System.out.println(i);
//		run as > argument > 값을 고정적으로 넣을 수 있는 
		for (String a : args) {
			System.out.println(a);
		}
	}

}
