
public class Q28 {

	public static void main(String[] args) {
		int a = 1;
		int b = a++ > 1 ? a + 2 : a + 3;
		System.out.print(b);
	}

}
