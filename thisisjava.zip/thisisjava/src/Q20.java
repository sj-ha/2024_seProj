interface Cals{
	public void get(int v);
}
interface Cals2{
	public void get(int v);
}

// 상속을 받았으면 무조건 구현을 해야 함.
class Test1 implements Cals, Cals2{
	public void get(int v) {
		System.out.println(v*v);
	}
}

public class Q20 {

	public static void main(String[] args) {
		Cals a = new Test1();
		a.get(10);
	}

}
