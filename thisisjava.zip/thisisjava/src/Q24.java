
public class Q24 {

	public static void main(String[] args) {
		String teststr = "         LoremIpsum    ";
		int a = teststr.trim( ).length();
		
		System.out.println(a);
	}

}
