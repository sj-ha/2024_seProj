
public class Q34 {

	public static void main(String[] args) {
		int num[] = {2, 1, 3, 7, 4, 9};
		int numb[] = new int[10];
		for (int i = 0; i < num.length; i++) {
			numb[i] = num[i];
		}
		for (int i : numb) {
			System.out.print(i);
		}
	}

}
