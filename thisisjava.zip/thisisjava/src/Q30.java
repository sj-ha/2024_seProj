// 문제가 오류를 발생하게 하는 것.

// 정상적으로 코드를 수정하게 된다면 getter/setter


//public > 전역범위 / private > class범위 / protected > package범위 / 
class Data{
	private int val = 0;
	void set(int a) {
		val = a;
	}
	int get() {
		return val;
	}
}
public class Q30 {

	public static void main(String[] args) {
		Data d = new Data();
		d.set(100);
		System.out.printf("%d", d.get()); // 오류 발생
	}

}
