
public class Q29 {

	public static void main(String[] args) {
		String str = "HelloWorld!";
//						substring(5) = 5자리 뒤부터 끝까지 다 나타냄.		
		String a1 = str.substring(5);
		System.out.print(a1.toUpperCase());
	}

}
