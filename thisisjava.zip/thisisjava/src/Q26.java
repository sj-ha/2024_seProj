import java.math.BigInteger;

public class Q26 {

	public static void main(String[] args) {
		BigInteger n = new BigInteger("12345");
		BigInteger m = new BigInteger("54321");
//		compareTo > n과 m을 비교
		System.out.println(n.compareTo(m));
//		n값과 m값이 같다면	   n    =  	   m    출력 0
//		n값이 m값 보다 크다면	   n    >  	   m    출력 1
//		n값 보다 m값이 크다면	   n    <  	   m    출력 -1
	}

}
