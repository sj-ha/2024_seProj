package ch03.sec11;

import java.util.Scanner;

public class ConditionalOperationExample {
	public static void main(String[] args) {
//		int score = 85;
//		char grade = (score > 90) ? 'A' : ( (score > 80) ? 'B' : 'C' );
//		System.out.println(score + "점은 " + grade + "등급입니다.");
		
//		##################################### practice
		System.out.println("점수를 입력해주세요.");
		Scanner sc = new Scanner(System.in);
		int score = sc.nextInt();
		String grade = (score >= 90) ? "우수" : ( (score >= 80) ? "보통" : (score >= 70) ? "부족" : "낙제" );
		System.out.println(score + "점 : " + grade);
		sc.close();
	}
}

