import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class OracleTest7 {
	public static void main(String args[]) {
		Connection conn = null; // DB연결된 상태(세션)을 담은 객체
		PreparedStatement pstm = null; // SQL 문을 나타내는 객체
		ResultSet rs = null; // 쿼리문을 날린것에 대한 반환값을 담을 객체

		System.out.println("이름을 입력하세요.");
		Scanner sc = new Scanner(System.in);
		try {
			String str = sc.next();

			// KING 의 이름, 사번, JOB, 급여, 급여등급, 부서명, 부서번호는?
			String query = "select e.ename, e.empno, e.JOB, e.sal, s.grade, d.dname, d.deptno "
					+ "from emp e, salgrade s, dept d " + "where  ( e.sal between s.losal and s.hisal ) "
					+ " and   ( e.deptno = d.deptno ) " + " and   (  e.ename = ?)";
			conn = DBConnection.getConnection();
			pstm = conn.prepareStatement(query);
			pstm.setString(1, str);
			rs = pstm.executeQuery(); // <- select

			System.out.println("이름, 사번, JOB, 급여, 급여등급, 부서명, 부서번호");
			System.out.println("============================================");

			while (rs.next()) {
				String ename = rs.getString("ename");
				int empno = rs.getInt("empno");
				String job = rs.getString("job");
				int sal = rs.getInt("sal");
				int grade = rs.getInt("grade");
				String dname = rs.getString("dname");
				int deptno = rs.getInt("deptno");

				String result = ename + " " + empno + " " + job + " " + sal + " " + grade + " " + dname + " " + deptno;
				System.out.println(result);
			}

		} catch (SQLException sqle) {
			System.out.println("SELECT문에서 예외 발생");
			sqle.printStackTrace();

		} finally {
			sc.close();
			// DB 연결을 종료한다.
			try {
				if (rs != null) {
					rs.close();
				}
				if (pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}

		}
	}
}
