
public class Q27 {

//	1. 2진수
//	2. 반전
//	3. +1
	public static void main(String[] args) {
//		>>    -5를 이진수로 바뀐 후 오른쪽으로 31번
		System.out.print(- 5 >> 31);
//		-5 > 5를 2의 보수(0101)로 변환 후 보수 > 1010 > 1(31개)1010 > +1 > 1(31개)1011
//		<< 일 때는 -(마이너스)일 때는 빈자리를 1로 채움 > 다 1일 경우 -1
		
		
		
//		**tip > java char=2byte / int=4byte / float=4byte / double=8byte
//		      > c    char=1byte
	}

}
