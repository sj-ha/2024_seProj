
public class Q32 {

	public static void main(String[] args) {
		int num1 = 3, num2 = 7;
		
		if (++num1 < 5 || ++num2 > 5) {
			System.out.println(num1);
		}
		System.out.println(num2);
	}

}
