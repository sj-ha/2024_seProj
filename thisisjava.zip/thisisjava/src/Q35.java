
public class Q35 {

	public static void main(String[] args) {
		int ans = 0;
		
		for (int i = 0; i < 100; i++) {
			if (i % 3 == 0) {
				ans++;
			} else if(i % 4 == 0) {
				ans--;
			}
		}
		System.out.println(ans);
	}

}

