package ch07.sec11;

//     final > Person 밑으로 상속을 받지 않겠다. 즉, 극단적인 차단.
public final class Employee extends Person {
	@Override
	public void work() {
		System.out.println("제품을 생산합니다.");
	}
}
