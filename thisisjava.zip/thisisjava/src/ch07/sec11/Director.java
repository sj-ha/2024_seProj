package ch07.sec11;

// 아래는 final이 없기 때문에 Manager 밑으로 상속을 계속 진행할 수 있다.
public class Director extends Manager {
	@Override
	public void work() {
		System.out.println("제품을 기획합니다.");
	}
}
