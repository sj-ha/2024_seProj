package ch07.sec11;

//	   non-sealed  >  누가 가져가든 개의치 않겠다.
public non-sealed class Manager extends Person {
	@Override
	public void work() {
		System.out.println("생산 관리를 합니다.");
	}
}
