package ch07.sec10.exam02;

public class Tiger extends Animal {

	@Override
	public void sound() {
		System.out.println("어흥");
	}

	@Override
	public void cry() {
		System.out.println("어르렁");
		
	}

}
