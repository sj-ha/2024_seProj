package ch07.sec10.exam02;

public class Duck extends Animal {

	@Override
	public void sound() {
		// TODO Auto-generated method stub
		System.out.println("꽥꽥");
	}

	@Override
	public void cry() {
		System.out.println("꽥르렁");
	}

}
