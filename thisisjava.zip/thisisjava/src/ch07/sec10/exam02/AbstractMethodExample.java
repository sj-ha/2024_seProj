package ch07.sec10.exam02;

public class AbstractMethodExample {
	public static void main(String[] args) {
//		Dog dog = new Dog();
//		dog.sound();
//		
//		Cat cat = new Cat();
//		cat.sound();

//		정석
//		AbstractMethodExample.animalSound(new Dog());
		//매개변수의 다형성
//		animalSound(new Dog());
//		animalSound(new Cat());
//		animalSound(new Duck());
//		animalSound(new Tiger());
		
//		위 축소 >> array 타입으로 담아서 foreach로 호출.
		Animal[] aniArr = {
				new Dog(), new Cat(), new Duck(), new Tiger()
		};
		for (Animal animal : aniArr) {
			animalSound(animal);
		}
		
	}
	
	public static void animalSound( Animal animal  ) {
		animal.sound();
		animal.cry();
	}
}
