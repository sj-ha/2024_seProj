package ch07.sec03.exam01;

public class Phone {
	//필드 선언
	public String model;
	public String color;
	
	//기본 생성자꼴 선언
	public Phone() {
		System.out.println("Phone() 생성자 실행");
	}
}
