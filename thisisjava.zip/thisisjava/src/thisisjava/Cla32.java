package thisisjava;

// interface의 경우 implements, interface의 접근자는 public이 기본이다.
interface TV {
	/*public abstract*/ void powerOn();
	/*public abstract*/ void powerOff();
}

class LGTV implements TV {
	public void powerOn() {
		System.out.println("LG TV 켭니다.");
	}

	public void powerOff() {
		System.out.println("LG TV 끕니다.");
	}
}

class SSTV implements TV {
	public void powerOn() {
		System.out.println("SS TV 켭니다.");
	}

	public void powerOff() {
		System.out.println("SS TV 끕니다.");
	}
}

class KTTV implements TV {
	public void powerOn() {
		System.out.println("KT TV 켭니다.");
	}

	public void powerOff() {
		System.out.println("KT TV 끕니다.");
	}
}

public class Cla32 {

	public static void main(String[] args) {
//		부모로의 타입 형 변환 > 다형성
		TV[] tvs = { new LGTV(), new KTTV(), new SSTV() };
		for (TV tv : tvs) {
			tv.powerOn();
			tv.powerOff();
		}
	}

}
