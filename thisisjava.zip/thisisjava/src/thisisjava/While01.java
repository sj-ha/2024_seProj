package thisisjava;

import java.util.Scanner;

public class While01 {

	public static void main(String[] args) {
//		For01.java for문을 while로 변환
		System.out.println("구구단 몇 단 >>>");

		Scanner sc = new Scanner(System.in);
//		구구단의 단 변수
		int dan = sc.nextInt();
		sc.close();
		
		int i = 1;
		
//		for (int i = 1; i <= 9; i++) {
//			System.out.printf("%d * %d = %d\n", dan, i, dan * i);
//		}
		
		while (i <= 9) {
			System.out.printf("%d * %d = %d\n", dan, i, dan * i);
			i++;
		}
	}

}
