package thisisjava;

class A28{
//	*** 범위 순 >>>  public > protected > default > protected
//	default 기본으로 속해 있는 해당 패키지에서 사용 가능
	/*default*/ int aa1 = 10;
//	public 항상 공개 *어디서든 가능
	public int aa2 = 100;
//	private 속해있는 클래스
	@SuppressWarnings("unused")
	private int aa3 = 1000;
//	protected 상속 관계 내 + default
	protected int aa4 = 10000;
}

class B28 extends A28{
	int bb1 = 20;
}

public class Cla28 {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		A28 a = new A28();
		B28 b = new B28();
	}

}
