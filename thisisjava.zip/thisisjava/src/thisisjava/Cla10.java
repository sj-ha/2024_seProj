package thisisjava;

class meth10{
	static int ans;
	static int sum(int a, int b) {
//		ans = a + b;
//		return ans;
		
//		선생님 에시
		return a + b;
	}

	static void sub(int a, int b) {
//		ans = a - b;
//		System.out.println(ans);
		
//		선생님 예시
		System.out.println(a - b);
	}

	static int Mul(int a, int b) {
//		ans = a * b;
//		return ans;
		
//		선생님 예시
		return a * b;
	}

	static void div(int a, int b) {
//		ans = a / b;
//		System.out.println(ans);
		
//		선생님 예시
		System.out.println(a / b);
	}
	
}

public class Cla10 {

	public static void main(String[] args) {
		int a = 20, b = 10;
		
//		30
		System.out.println(meth10.sum(a, b));
//		10
		meth10.sub(a, b);
//		100
		System.out.println(meth10.Mul(a, b));
//		2
		meth10.div(a, b);
	}

}
