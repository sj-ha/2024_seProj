package thisisjava;

class Meth14{
	static int staticCnt = 0;
	int instanceCnt = 0;
	void count() {
		int localCnt = 0;
		staticCnt++;
		instanceCnt++;
		localCnt++;
		System.out.printf("%d,%d,%d\n", staticCnt, instanceCnt, localCnt);
	}
}

public class Cla14 {

	public static void main(String[] args) {
		Meth14 m1 = new Meth14();
		m1.count();
		m1.count();
		m1.count();
		
		Meth14 m2 = new Meth14();
		m2.count();
		m2.count();
		m2.count();
	}

}
