package thisisjava;

class Meth08{
//	static 없었을 땐 instance로 작용한다. > 즉, static은 공용 변수로 사용 된다.
	static int iMoney;
	void setMoney(int i, int o) {
		iMoney = iMoney + i - o;
	}
	void getMoney() {
		System.out.println(iMoney);
	}
}

public class Cla08 {

	public static void main(String[] args) {
		Meth08 m = new Meth08();
		Meth08 w = new Meth08();
		Meth08 c = new Meth08();
		
		m.setMoney(20000, 13000);
		m.getMoney();
		w.setMoney(30000, 10000);
		w.getMoney();
		c.setMoney(900, 400);
		c.getMoney();
	}

}
