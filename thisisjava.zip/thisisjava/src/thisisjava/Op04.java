package thisisjava;

public class Op04 {
	public static void main(String[] args) {
		int a = 7, b = 3;
		System.out.println((a == b) && (a > b++));// false
		System.out.println(b);  // 3
		System.out.println("=======================");

//		비트연산자(&)로 1과 0으로 변환되기 때문에 무조건 실행이 되는 이유이다.
		System.out.println((a == b) & (a > b++));// false
		System.out.println(b);  // 4
		System.out.println("=======================");

		System.out.println((a != b) || (a > b++));// true
		System.out.println(b);  // 4
		System.out.println("=======================");

		System.out.println((a != b) | (a > b++));// true
		System.out.println(b);  // 5

	}

}
