package thisisjava;

// class의 상위 class인 Object 설명 > Object는 기본이라 생략 된다. 
class Ani24 extends Object{
	String name;
	int age;
	void cry() {
		
	}
}

class Dog24 extends Ani24{
	String nickname;
}

public class Cla24 {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Ani24 a1 = new Ani24();
		Dog24 d1 = new Dog24();
//		d1.
	}

}
