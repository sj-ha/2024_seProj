package thisisjava;

import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

// 파일 입출력(데이터 입출력) 예제
// 메모리와 디스크 사이
// 폴더 & 파일 생성 예제
// writer도 똑같이 close(); 해줘야 함.
public class FileEx02 {

	public static void main(String[] args) throws IOException {
		Writer wr = new FileWriter("C:\\temp\\test01.txt");
		String txt = "안녕 자바 프로그램";
		
//		wr.write(txt);
//		write(파일명, 위치, 몇 글자);
//		wr.write(txt, 6, 4);
		wr.write(txt);
//		파일 입출력 시 비워줘야 한다.
		wr.flush();
		wr.close();
		
		System.out.println("실행 성공");
	}

}
