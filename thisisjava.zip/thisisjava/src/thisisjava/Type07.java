package thisisjava;

public class Type07 {

	public static void main(String[] args) {
		String s1 = "apple", s2 = "포도";
		int a1 = 500, a2 = 700;
		
		System.out.println(s1 + "가격은 " + a1 + "원이다.");
		System.out.printf("%s가격은 %d원이다.", s1, a1);
//		참조 p71
		System.out.printf("%s가격은 %d원이다.", s1, a1);
		
		System.out.println("\n==================1=====================");
//		ex1 > 포도는 700원이다.
		System.out.printf("%s가격은 %d원이다.", s2, a2);
		
		System.out.println("\n=================2======================");
		String s3 = "딸기", s4 = "수박";
		float a3 = 900.99f;
		double a4 = 3333.33;
		
//		ex2. 딸기 가격은 900.99원이다. 참조 p71
//		딸기가격은 900.989990원이다.
		System.out.printf("%s가격은 %f원이다.\n", s3, a3);
//		딸기가격은 900.99원이다.  > 소수점자리 2번째부터 자름
		System.out.printf("%s가격은 %.2f원이다.\n", s3, a3);
//		딸기가격은 901.0원이다.  > 
		System.out.printf("%s가격은 %.1f원이다.\n", s3, a3);
		
		System.out.println("\n===============3========================");
//		ex3. 수박 가격은 3333.33원이다.
//		수박가격은 3333원이다.  > 소수점 뒤로 자름.
		System.out.printf("%s가격은 %.0f원이다.", s4, a4);
		
		System.out.println("\n==============4=========================");
		System.out.printf("%s가격은 %d원이다.\n", "과일", 45678);
		System.out.printf("%s가격은 %3d원이다.\n", "과일", 45678);
		System.out.printf("%s가격은 %10d원이다.\n", "과일", 45678);
		System.out.printf("%s가격은 %010d원이다.\n", "과일", 45678);
		System.out.printf("%s가격은 %-10d원이다.\n", "과일", 45678);

		System.out.println("\n===============5========================");
		System.out.printf("%s가격은 %f원이다.\n", "과일", 123.45);
		System.out.printf("%s가격은 %5f원이다.\n", "과일", 123.45);
		System.out.printf("%s가격은 %.2f원이다.\n", "과일", 123.45);
		System.out.printf("%s가격은 %5.2f원이다.\n", "과일", 123.45);
		
		System.out.println("\n================6=======================");
		System.out.printf("%s는 과일이다.\n", "사과");
		System.out.printf("%5s는 과일이다.\n", "사과");
		System.out.printf("%-5s는 과일이다.\n", "사과");
		
	}

}
