package thisisjava;

import java.util.Scanner;

public class Q17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int inNum;
		Scanner scan01 = new Scanner(System.in);
		scan01.close();
		inNum = scan01.nextInt();
		if (inNum % 2 == 0) {
			System.out.println("짝수");
		} else {
			System.out.println("홀수");

		}
	}

}
