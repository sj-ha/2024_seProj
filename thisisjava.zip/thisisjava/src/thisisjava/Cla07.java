package thisisjava;

// 가변 길이
// 같은 이름, 다른 타입 => 오버로딩
// 입력 값 => 가변 길이 매개 변수(Type ... 변수) (값1, 값2, ...) / (배열)
// ㄴ 배열(Type[] 변수) => 배열도 가능
class Meth07{
	int sum00(int[] iArray) {
		int ans = 0;
		for (int i : iArray) {
			ans += i;
		}
		return ans;
	}
	
	int sum01(int ... iArray) {
		int ans = 0;
		for (int i : iArray) {
			ans += i;
		}
		return ans;
	}
	
	String sum01(String ... iArray) {
		String ans = "";
		for (String i : iArray) {
			ans += i;
		}
		return ans;
	}
}

public class Cla07 {

	public static void main(String[] args) {
		Meth07 m1 = new Meth07();
		
		int res1 = 0;
//		30
		res1 = m1.sum01(20, 10);
		System.out.println(res1);
		
//		35
		res1 = m1.sum01(20, 10, 5);
		System.out.println(res1);
		
//		38
		res1 = m1.sum01(20, 10, 5, 3);
		System.out.println(res1);
		
//		40
		res1 = m1.sum01(20, 10, 5, 3, 2);
		System.out.println(res1);
		System.out.println("#########################");
		
		
//		메서드가 array로 선언됐다면 쓰는 것도 array 형태여야 한다. 아래의 두 가지 방법으로 쓸 수 있다.
		int[] iArr01 = {20, 10};
//		30
		res1 = m1.sum00(iArr01);
		System.out.println(res1);
		
//		35
		res1 = m1.sum00(new int[] {20, 10, 5});
		System.out.println(res1);
		
//		30
		res1 = m1.sum01(iArr01);
		System.out.println(res1);
		System.out.println("#########################");
		
		
		String str = null;
//		서초여성인력
		str = m1.sum01("서초", "여성", "인력");
		System.out.println(str);
		
//		개발센터
		str = m1.sum01("개발", "센터");
		System.out.println(str);
	}

}
