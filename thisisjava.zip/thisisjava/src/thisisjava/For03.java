package thisisjava;

import java.util.Scanner;

public class For03 {

	public static void main(String[] args) {
//		구구단 3단
//	   불변 변화(선행)     > 선행 되는 수의 변화를 확인 후 먼저 도출 후 식에 맞게 변화
//		3 * 1 = 3
//		3 * 2 = 6
//		3 * 3 = 9
//		~~~
//		3 * 9 = 27
//		3 * 10 = 30
//		for (int i = 1; i <= 10; i++) {
////			선생님 예시
//			System.out.printf("3 * %d = %d\n", i, i*3);
//			
////			int a = 3;
////			System.out.println(a + " * " + i + " = " + (a * i));
//		}
		
		System.out.println("구구단 몇 단 >>>");
		
		Scanner sc = new Scanner(System.in);
//		구구단의 단 변수
		int dan = sc.nextInt();
		sc.close();
		
		for (int i = 1; i <= 9; i++) {
			System.out.printf("%d * %d = %d\n", dan, i, dan * i);
		}
		
	}

}
