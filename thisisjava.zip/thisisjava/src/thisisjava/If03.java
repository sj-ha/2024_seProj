package thisisjava;

import java.util.Scanner;

public class If03 {

	public static void main(String[] args) {
		System.out.println("숫자를 입력하세요.");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt() % 4;
		sc.close();
//		n = n % 4;
		String str = null;
		if (n == 1) {
			str = "가위";
		} else if (n == 2) {
			str = "바위";
		} else if (n == 3) {
			str = "보";
		} else {
			str = "기타";
		}
		System.out.println("값 : " + n + "\n결과 : " + str);
	}

}
