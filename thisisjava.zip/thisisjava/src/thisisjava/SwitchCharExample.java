package thisisjava;

public class SwitchCharExample {
	public static void main(String[] args) {
		char grade = 'A';

		switch (grade) {
//		break문이 없기 때문에 다음 case까지 이어짐.
		case 'A':
			System.out.println("최우수 회원입니다.");
			break;
		case 'a':
			System.out.println("우수 회원입니다.");
			break;
		case 'B':
		case 'b':
			System.out.println("일반 회원입니다.");
			break;
		default:
			System.out.println("손님입니다.");
		}
	}
}
