package thisisjava;

class Sing18{
//	싱글톤 패턴으로 한 번만 사용할 때
	private static Sing18 sing = new Sing18();
	private Sing18() {
		
	}
	static Sing18 getInstance() {
		return sing;
		
	}
}

public class Cla18 {

	public static void main(String[] args) {
//		Sing18 s1 = new Sing18();
//		Sing18 s2 = new Sing18();
		
		Sing18 s1 = Sing18.getInstance();
		Sing18 s2 = Sing18.getInstance();
		
		System.out.println(s1 == s2);
	}

}
