package thisisjava;

public class Arr06 {

	public static void main(String[] args) {
		String s1 = "사과", s2 = "사과";
		String[] sArr1 = {"사과", "배", "바나나"};
//		for (String iA : sArr1) {
//			System.out.print(iA + " ");
//		}

		
//		true
//		true
//		true
//		true
		System.out.println(s1 == s2);
		System.out.println(s1.equals(s2));
		
		System.out.println(s1 == sArr1[0]);
		System.out.println(s1.equals(sArr1[0]));
	}

}
