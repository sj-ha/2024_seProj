package thisisjava;

import java.util.Scanner;

public class Test00 {

	public static void main(String[] args) {
		System.out.println("String Line 입력 => ");
		Scanner sc = new Scanner(System.in);
		String[] sArr = sc.nextLine().split(" ");
		sc.close();
		
		int iAns = 0;
		for (String string : sArr) {
			iAns += Integer.parseInt(string);
		}
		System.out.println(iAns);
	}

}
