package thisisjava;

class Book38{
	private String title;
	private String author;
	private int price;
	
	Book38(String title, String author, int price){
		this.title = title;
		this.author = author;
		this.price = price;
	}
	
	@Override
	public String toString() {
		return "책 제목 : " + this.title + "\n저자 : " + this.author + "\n가격 : " + this.price;
	}
}

public class Cla38 {

	public static void main(String[] args) {
		Book38 book38 = new Book38("Tom", "JAVA", 30000);
		System.out.println(book38.toString());
	}

}
