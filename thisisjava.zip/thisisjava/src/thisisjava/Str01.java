package thisisjava;

import java.util.Scanner;

public class Str01 {

	public static void main(String[] args) {
//		값 형인 경우 
//		값 비교
		int i1 = 20, i2 = 10, i3 = 20;
		System.out.println(i1 == i2);
		System.out.println(i1 == i3);
		
//		참조형인 경우 데이터가 만들어지고 값이 들어감
//		데이터 비교
		
		
//		if 조건문 (== / equals)   차이점 >
//		참조형의 경우 heap에 주소가 저장 된다.
//		값 형의 경우 stack에 값이 저장 된다.
//		참조형의 경우 .equals는 heap의 주소까지 비교
		String s1 = "KR", s2 = "KR";
		System.out.println(s1 == s2);
		System.out.println(s1.equals(s2));
		
		
		System.out.println("KR 입력 => ");
		Scanner sc = new Scanner(System.in);
		String s3 = sc.next();
		sc.close();
		
		System.out.println(s1 == s3);
		System.out.println(s1.equals(s3));
		
	}

}
