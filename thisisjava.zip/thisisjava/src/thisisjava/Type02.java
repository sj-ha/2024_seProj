package thisisjava;

public class Type02 {

	public static void main(String[] args) {
//		Exception in thread "main" java.lang.Error: Unresolved compilation problem: 
//			The local variable a1 may not have been initialized
//
//			at thisisjava.type02.main(type02.java:8)
//		초기 값 설정이 안 된 에러
//		byte a1;
//		System.out.println(a1);
		
		
//		값 형은 값을 설정해줘야 한다.
		byte a1 = 10;  // byte = 1byte
		short a2 = 20; // short = 2byte
		int a3 = 30;   // int = 4byte
		long a4 = 40;  // long = 8byte
		char a5 = 'A';  // char = 2byte
		char a6 = '강';  // char = 2byte
//		char의 경우 한 자만 가능하다. 한 자를 넘어가는 경우 string으로 선언해야 한다.
//		char a7 = '서울';  // char = 2byte
		
//		참조형 : ""(큰따옴표)가 있게 되면 데이터가 먼저 생긴다.
		String a7 = "서울";  // string
		
		System.out.println(a1);
		System.out.println(a2);
		System.out.println(a3);
		System.out.println(a4);
		System.out.println(a5);
//		int로 변형하게 되면 10진수로 나타낸다. 65
		System.out.println((int)a5);
//		아스키코드 참조할 것. 97
		System.out.println((int)'a');
		System.out.println(a6);
		System.out.println(a7);
		
//		문자도 1,0이라고 하는 값으로 저장.
//		heap에 주소가 있다면 참조형
	}

}
