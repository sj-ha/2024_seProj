package thisisjava;

class Ani21 {
	String name = "동 물";
//
	void cry() {
		System.out.println("으 앙");
	}

	Ani21() {
		System.out.println("Ani21 실행");
	}
}

class Dog21 extends Ani21 {
	String name = "강아지";
	
	@Override
	void cry() {
		System.out.println("멍 멍");
	}
	
	Dog21() {
//		super > 상속 시 super는 은닉.
		super();
		System.out.println(super.name);
		super.cry();
		System.out.println("Dog21 실행");
		System.out.println(this.name);
		this.cry();
	}

}

public class Cla21 {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Dog21 d1 = new Dog21();
//		System.out.println(d1.name);
//		d1.cry();
//		System.out.println(d1.age);
	}

}
