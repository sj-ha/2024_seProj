package thisisjava;

import java.awt.Toolkit;

// 람다식 Thread을 이용한 멀티 스레드 예시
public class BeepEx5 {

	public static void main(String[] args) {
		Thread th = new Thread(() -> {
//			띵 소리 5번
			Toolkit tk = Toolkit.getDefaultToolkit();
			for (int i = 0; i < 5; i++) {
				tk.beep();
				try {
					Thread.sleep(1000);
				} catch (Exception e) {
					System.out.println(e);
				}
			}
		});

		th.start();

//		띵 문자 5번
		for (int i = 0; i < 5; i++) {
			System.out.println("띵");
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}

}
