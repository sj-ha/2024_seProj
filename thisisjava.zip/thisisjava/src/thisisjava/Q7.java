package thisisjava;

public class Q7 {

	public static void main(String[] args) {
		String str = "HRDK" + 40 + 23;
		System.out.println(str);
	}

}
