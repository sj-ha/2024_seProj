package thisisjava;

public class Q9 {

	public static void main(String[] args) {
		int a = 9;
		int b = 11;
//				 || or : 0과 1을 더해서 1이면 true 0 이면 false
//				 && and : 0과 1을 곱해서 1이면 false
//				 ^ = 배타적 or(o+ xor) : 값이 다를 때만 0		
		int c = a^b;
		System.out.println(c);
		
		
//		8 4 2 1 > 2진수
	}

}
