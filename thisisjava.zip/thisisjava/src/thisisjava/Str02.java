package thisisjava;

public class Str02 {

	public static void main(String[] args) {
		String s1 = "KR";
		String s2 = "KR";
		
		System.out.println(s1 == s2);
		System.out.println(s1.equals(s2));
		
		String s3 = new String("KR");
//		new String을 선언해서 문자열을 넣게 되면 공간을 새로 만들어서 들어가는 것이기 때문에
		System.out.println(s1 == s3);
//		아래 값은 'false' 왜? > new String으로 주소 값이 달라지기 때문.
		System.out.println(s1.equals(s3));
	}

}
