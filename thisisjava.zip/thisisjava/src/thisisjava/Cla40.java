package thisisjava;

class Q40 {
	private String ans;

	Q40() {
		this.ans = "";
	}

	void test() {
		System.out.print(ans);
	}

	<T> void test(T i) {
		this.ans += i.toString();
	}

	void test(int i) {
		this.ans += i * 2;
	}
}

public class Cla40 {
	public static void main(String[] args) {
		Q40 a = new Q40();
		a.test("abs");
		a.test();
		a.test(1.0);
		a.test(2);
		a.test();
	}

}
