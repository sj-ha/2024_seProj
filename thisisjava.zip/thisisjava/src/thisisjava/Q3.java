package thisisjava;

public class Q3 {
	int a, b, c;
	public static void main(String[] args) {
		Q3 myInt = new Q3();
		myInt.a = 8;
		myInt.b = 10;
		hrd(myInt);
		System.out.println("a = " + myInt.a);
		System.out.println("b = " + myInt.b);
		System.out.println("c = " + myInt.c);
}


	static void hrd(Q3 myInt) {
		if (myInt.a++ >= myInt.b--) {
			myInt.c = myInt.a + myInt.b;
		} else {
			myInt.c = myInt.a - myInt.b;
		}
	}
}
