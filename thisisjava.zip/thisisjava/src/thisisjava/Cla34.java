package thisisjava;

interface Ani34{
//	interface는 public static final이 생략돼 있다.
	public static final String name1 = "해피";
	String name2 = "아치";
	
//	public abstract 또한 생략돼 있다.
	public abstract void cry1();
	void cry2();
	
//	default로 메서드 생성 시 구현부를 생성할 수 있다. **이전에는 불가했음.
	default void shout() {
		System.out.println("야~");
	}
}

class Dog34 implements Ani34{
	@Override
	public void cry1() {
		System.out.println("멍멍");
	}
	@Override
	public void cry2() {
		System.out.println("뭉뭉");
	}
}

public class Cla34 {

	public static void main(String[] args) {
		Dog34 d1 = new Dog34();
		d1.cry1();
		d1.cry2();
		d1.shout();
	}

}
