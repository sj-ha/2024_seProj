// 일반 class			abstract class			interface
//	메서드(){}		메서드(); 메서드(){}		메서드();
// *** 단순한 프로그램인 경우 abstract class로 할 수 있으나 상속 문제로 프로그램이 무거워진다.

package thisisjava;



// 클래스는 다중 상속이 불가하다. > 모든 클래스의 최상위 클래스가 Object. 
//class A27{
//	
//}
//class B27{
//	
//}
//class C27 extends A27, B27{
//	
//}


// 인터페이스는 허상의 공간이기 때문에 다중 상속이 가능하다.
interface A27{
	
}
interface B27{
	
}
interface C27 extends A27, B27{
	
}

public class Cla27 {

	public static void main(String[] args) {
		System.out.println("인터페이스 다중 상속 실행");
	}

}
