package thisisjava;

public class Type03 {

	public static void main(String[] args) {
//		소수점
//		float a1 = (float) 3.14;
//		float의 경우 소수점이라는 걸 인지하기 위해 맨 뒤에 f를 넣는다.
		float a1 = 3.14f;
		double a2 = 3.14;
//		3.14
//		3.14
		System.out.println(a1);
		System.out.println(a2);
		
		boolean b1 = true;
		boolean b2 = 3 > 4;
//		true
//		false
		System.out.println(b1);
		System.out.println(b2);
	}

	
}
