package thisisjava;

public class Op01 {

	public static void main(String[] args) {

		int i1 = 20, i2 = 10;
		System.out.println(i1 + i2);// 산술연산자
		System.out.println(i1 - i2);
		System.out.println(i1 * i2);
		System.out.println(i1 / i2);
		System.out.println(i1 % i2);
		System.out.println("=========================");

		String s1 = "30", s2 = "40";
		System.out.println(s1 + s2);// 연결연산자
		System.out.println("=========================");

		int i3 = Integer.parseInt(s1) + Integer.parseInt(s2); // Quiz
		System.out.println(i3);// 70
		System.out.println("=========================");

		int i4 = 100;
		i4 = i4 + 2;
		System.out.println(i4);
		System.out.println("=========================");

		i4 += 2;
		System.out.println(i4);
		System.out.println("=========================");

		i4 *= 2;
		System.out.println(i4);
		System.out.println("=========================");

		i4 /= 2;
		System.out.println(i4);
		System.out.println("=========================");

//		2진법			
//		3	011
//		2	010
//		1	001     ㄱ -> 비트연산자로 하게 되면
//		0	000		|
//		---------  	|						부호 비트 : 맨 앞자리가 0이면 양수, 1이면 음수
//		-1	111		|
//		-2	110	   <- 110으로 된다.
//		-3	101
//		-4	100

//		byte의 최소값 -128 / 최대값 127
//		오버플로우 : 최대값을 넘어갈 때
//		언더플로우 : 최소값을 넘어갈 때
//		오버플로우와 언더플로우로 인해 최대값을 넘어갈 경우 최소값으로 가게 되고 최소 값을 넘어갈 경우 최대값으로 넘어간다.
		byte b1 = 127;
		// b1 = b1 + 1;
		System.out.println(b1 + 1);
		b1 += 1;
		System.out.println(b1);
		System.out.println(b1 + 1);

		System.out.println("=========================");
		byte b2 = -128;
		System.out.println(b2 - 1);
		b2 += 1;
		System.out.println(b2);

		System.out.println("=========================");
//		Exception in thread "main" java.lang.ArithmeticException: / by zero
//		at thisisjava.Op01.main(Op01.java:72)		
//		정수로 나눗셈을 못 하기 때문에 zero 에러가 뜸.
//		System.out.println(5/0);
//		System.out.println(5%0);
		System.out.println(5 / 0.0);
		System.out.println(5 % 0.0);

	}

}
