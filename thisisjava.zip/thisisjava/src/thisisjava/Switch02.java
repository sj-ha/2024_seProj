package thisisjava;

import java.util.Scanner;

public class Switch02 {
	public static void main(String[] args) {
		String str1 = null;
		System.out.println("동서남북 중 입력해주세요.");
		Scanner sc = new Scanner(System.in);
		String str2 = sc.next();
		sc.close();
		System.out.println("입력한 값 : " + str2);

		switch (str2) {
//		break문이 없기 때문에 다음 case까지 이어짐.
		case "동":
			str1 = "East";
			break;
		case "서":
			str1 = "West";
			break;
		case "남":
			str1 = "North";
			break;
		case "북":
			str1 = "South";
			break;
		default:
			str1 = "기타";
		}
		System.out.println(str1);
	}
}
