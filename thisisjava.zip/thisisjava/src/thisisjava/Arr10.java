package thisisjava;

public class Arr10 {

	public static void main(String[] args) {
		String[][] sArr01 = { { "배", "감", "귤" }, { "봄", "밤", "눈" }, { "꽃", "곰", "펜" } };

		///////////////////////////////////////
		// 세로방향으로 0 ~ 2 까지 출력
		for (int i = 0; i < sArr01.length; i++) {
			for (int j = 0; j < sArr01[i].length; j++) {
				System.out.print(sArr01[i][j] + " ");
			}
			System.out.println();
		}

		String[][] sArr02 = { { "배", "감", "귤", "눈" }, { "봄", "밤" }, { "꽃", "곰", "펜" } };

		for (int i = 0; i < sArr02.length; i++) {
			for (int j = 0; j < sArr02[i].length; j++) {
				System.out.print(sArr02[i][j] + " ");
			}
			System.out.println();
		}

	}
}
