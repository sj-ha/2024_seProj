package thisisjava;

class Book16 {
	private String title;
	private String author;
	int price;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
}

public class Cla16 {

	public static void main(String[] args) {
		Book16 b1 = new Book16();
		b1.setTitle("Java");
		System.out.println(b1.getTitle());
		b1.setAuthor("홍길동");
		System.out.println(b1.getAuthor());
		b1.setPrice(10000);
		System.out.println(b1.getPrice());
	}

}
