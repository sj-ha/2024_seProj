package thisisjava;

class Book03 {
	String title = "무제";
	String author = "작자미상";
	int price = 0;

	Book03(String title, String author, int price) {
		this.title = title;
		this.author = author;
		this.price = price;
	}

	Book03(String title, String author) {
		this.title = title;
		this.author = author;
	}

	Book03(String title) {
		this.title = title;
	}

	Book03() {
	}

	void pBook() {
		System.out.println(this.title + "," + this.author + "," + this.price);
	}
}

public class Cla03 {

	public static void main(String[] args) {
		Book03 b1 = new Book03("APT", "로제", 10000);
		b1.pBook(); // => APT,로제,10000
		Book03 b2 = new Book03("자바", "Tom");
		b2.pBook(); // => 자바,Tom,0
		Book03 b3 = new Book03("기사");
		b3.pBook(); // => 기사,작자미상,0
		Book03 b4 = new Book03();
		b4.pBook(); // => 무제,작자미상,0
	}

}
