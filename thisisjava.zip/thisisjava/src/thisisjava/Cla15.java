package thisisjava;

class Book15{
	String title = "무제";
	String author = "미상";
	int price = 1000;
	
	Book15(){
		System.out.println(title + ", " + author + ", " + price);
	}
	
	Book15(String title, String author, int price){
//		아래 this는 속해있는 생성자를 호출할 수 있다.
		this();
		System.out.println(title + ", " + author + ", " + price);
		System.out.println(title + ", " + author + ", " + price);
	}
	
//	void pBook(){
////		System.out.println(title + ", " + author + ", " + price);
////		선생님 예시
//		System.out.println(this.title + ", " + this.author + ", " + this.price);
//	}
}

public class Cla15 {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Book15 b1 = new Book15();
//		b1.pBook();
		Book15 b2 = new Book15("Java", "Tom", 10000);
		
	}

}
