package thisisjava;

class Meth05{
//	반환 Type 이름(입력){
//		처리; return 반환 값;
//	}
	
//	입력 O, 반환 O
	int Sum(int x, int y) {
		int ans = x + y;
		return ans;
	}
//	입력 O, 반환 X
	void Sub(int x, int y) {
		int ans = x - y;
		System.out.println(ans);
	}
//	입력 X, 반환 O
	int Mul() {
		int ans = 20 * 10;
		return ans;
	}
//	입력 X, 반환 X
	void Div() {
		int ans = 20 / 10;
		System.out.println(ans);
	}
}

public class Cla05 {

	public static void main(String[] args) {
		Meth05 m1 = new Meth05();
		
		int res1 = m1.Sum(20, 10);
		System.out.println(res1);
		
		m1.Sub(20, 11);
		
		int res2 = m1.Mul();
		System.out.println(res2);
		
		m1.Div();
	}

}
