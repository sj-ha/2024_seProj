package thisisjava;

import java.util.Scanner;

public class Switch01 {
	public static void main(String[] args) {
		System.out.println("숫자를 입력하세요.");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt() % 2;
		sc.close();
		String ans = null;

//		if문 예시
//		if ((n) == 0) {
//			ans = "짝수";
//		} else if ((n) == 1) {
//				ans = "홀수";
//		} else {
//			ans = "기타";
//		}
		
//		switch문에는 항상 break
		switch (n) {
		case 0:
			ans = "짝수";
			break;
		case 1:
			ans = "홀수";
			break;

		default:
			ans = "기타";
			break;
		}
		
		System.out.println(ans);
	}

}
