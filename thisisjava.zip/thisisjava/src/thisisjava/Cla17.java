package thisisjava;

class Point17 {
	int x, y;

	public Point17(int i, int j) {
		this.x = i;
		this.y = j;
		System.out.println(this.x + ", " + this.y);
	}
	
//	p1/p2 x끼리 더하기, p1/p2 y끼리 더하는 예시 메서드
	static Point17 pSum(Point17 i, Point17 j) {
		int ixy = i.x + i.y;
		int jxy = j.x + j.y;
		return new Point17(ixy, jxy);
	}
	
//	좌표끼리의 넓이 구하는 예시 메서드
	static int pRec(Point17 i, Point17 j) {
		int a = j.x - i.x;
		int b = i.y - i.x;
		return (a * b);
	}
}

public class Cla17 {

	public static void main(String[] args) {
		Point17 p1 = new Point17(20, 10);
		Point17 p2 = new Point17(35, 25);
		@SuppressWarnings("unused")
		Point17 p3 = Point17.pSum(p1, p2);
		System.out.println(Point17.pRec(p1, p2));
	}

}
