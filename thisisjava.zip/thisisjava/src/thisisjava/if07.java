package thisisjava;

import java.util.Scanner;

public class if07 {

	public static void main(String[] args) {

		int num = (int) (Math.random() * 3);

		String sRan;
		if (num == 0) {
			sRan = "가위";
		} else if (num == 1) {
			sRan = "바위";
		} else {
			sRan = "보";
		}

		System.out.println("가위/바위/보 입력 => ");
		Scanner sc = new Scanner(System.in);
		String sMe = sc.next();
		sc.close();

		System.out.printf("나 : %s, 상대 : %s \n", sMe, sRan);
		// 비기는 경우 (가위-가위, 바위-바위, 보-보)
		if ((sMe.equals("가위") || sMe.equals("바위") || sMe.equals("보"))) {
			if (sMe.equals(sRan)) {
				System.out.println("비김");
			} else if ((sMe.equals("가위") && sRan.equals("보")) || (sMe.equals("바위") && sRan.equals("가위")) || (sMe.equals("보") && sRan.equals("바위"))) {
				// 이기는 경우 (가위-보 || 바위-가위 || 보-바위)
				System.out.println("이김");
			} else {
				// 지는 경우
				System.out.println("졌음");
			}
		} else {
			System.err.println("가위.바위.보 중에서 입력하세요.");
		}
	}

}
