package thisisjava;

public class For05 {

	public static void main(String[] args) {
//		1~10까지의 수 중에서 7을 넘지 않고 홀수만 출력
		for (int i = 1; i <= 10; i++) {
//			7을 넘지 마라
			if (i >= 7) {
				break;
			}

//			홀수가 되면 앞으로 가라
			if (i % 2 == 1) {
//				continue  =>  앞으로 이동해서 for문을 실행
				continue;
			}
// 			1 ~ 10까지 가로 방향 출력
			System.out.print(i + " ");
		}
	}

}
