package thisisjava;

class A26{
	
}
//	   ^ 상속
class B26 extends A26{
	
}
//	   ^^ 상속
class C26 extends A26{
	
}
//	   ^^ 상속
class D26 extends B26{
	
}
//	   ^^상속
class E26 extends C26{
	
}

public class Cla26 {

	public static void main(String[] args) {
		B26 b = new B26();
		C26 c = new C26();
		D26 d = new D26();
		E26 e = new E26();
		
		@SuppressWarnings("unused")
		A26 a2 = b;
		@SuppressWarnings("unused")
		A26 a1 = c;
		@SuppressWarnings("unused")
		A26 a3 = d;
		@SuppressWarnings("unused")
		A26 a4 = e;
		
		@SuppressWarnings("unused")
		B26 b1 = d;
		@SuppressWarnings("unused")
		C26 c1 = e;
//		B26 b3 = e;
//		C26 c3 = d;
		
//		instanceof 형변환 확인이 가능하다.
		System.out.println(d instanceof B26);
		System.out.println(d instanceof A26);
		System.out.println(b instanceof D26);
		System.out.println("===========");
		System.out.println(e instanceof C26);
		System.out.println(e instanceof A26);
	}

}
