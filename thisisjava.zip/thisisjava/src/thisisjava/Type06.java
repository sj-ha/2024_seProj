package thisisjava;

public class Type06 {

	public static void main(String[] args) {
//		같은 사이즈를 stack 안에서 위아래로 움직인 것.
		short a1 = 10;
//		자동 형 변환
		int a2 = a1;
		System.out.println(a2);
		
//		강제 형 변환
		short a3 = (short) a2;
		System.out.println(a3);
		
		int a4 = 20;
//		Exception in thread "main" java.lang.Error: Unresolved compilation problem: 
//			Type mismatch: cannot convert from int to String
//
//			at thisisjava.type06.main(type06.java:16)
//		heap과 stack의 변환으로 인한 에러
//		String s4 = a4;
//		String.valueOf => int a4가 깂으로 올 수 없기 때문에 값을 heap으로 옮기고 주소만 가져오는 것임.
		String s4 = String.valueOf(a4);
		System.out.println(s4);
		
//		참조 p67
		String s5 = "30";
		int a5 = Integer.parseInt(s5);
		System.out.println(a5);
		
//		참조 2권 p527 타입 -> 클래스 : 포장(wrapper) 객체
		String s6 = "40";
//		short a6 = s6;
		short a6 = Short.parseShort(s6);
		System.out.println(a6);
	}

}
