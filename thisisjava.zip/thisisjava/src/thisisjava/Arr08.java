package thisisjava;

public class Arr08 {

	public static void main(String[] args) {
		int[][] iArr01 = { { 1, 2, 3, 4 }, { 5, 6 }, { 7, 8, 9 } };

		for (int i = 0; i < iArr01.length; i++) {
			for (int j = 0; j < iArr01[i].length; j++) {
				System.out.print(iArr01[i][j] + " ");
			}
			System.out.println();
		}

	}

}
