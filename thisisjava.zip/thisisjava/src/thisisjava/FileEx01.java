package thisisjava;

import java.io.File;
import java.io.IOException;

// 파일 입출력(데이터 입출력) 예제
// 메모리와 디스크 사이
// 폴더 & 파일 생성 예제
public class FileEx01 {

	public static void main(String[] args) throws IOException {
		File dir = new File("C:\\temp\\sub02");
		File file = new File("C:\\temp\\test02.txt");
		
		if (dir.exists() == false) {
			dir.mkdir();
		}
		if (file.exists() == false) {
			file.createNewFile();
		}
		System.out.println("실행 성공");
	}

}
