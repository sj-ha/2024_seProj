package thisisjava;

public class Q14 {

	public static void main(String[] args) {
		int n;
		n = 10;
		increase(n);
		System.out.printf("%d", n);
	}

	static void increase(int n) {
		n = n + 1;
	}

}
