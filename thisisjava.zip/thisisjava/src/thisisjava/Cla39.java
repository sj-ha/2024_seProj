package thisisjava;

class Q39{
	private String ans;
	Q39(String ans) {
		this.ans = ans;
	}
//	void test(String i) {
//		this.ans += i;
//	}
//	위의 test() 제네릭 변환
	<T> void test(T i) {
		this.ans += i.toString();
	}
	void test(int i) {
		this.ans += i * 2;
	}
	void test() {
		System.out.println(this.ans);
	}
}

public class Cla39 {

	public static void main(String[] args) {
		Q39 q39 = new Q39("AB");
		q39.test();
		q39.test("C");
		q39.test(7);
		q39.test(false);
		q39.test(1.0);
		q39.test();
	}

}
