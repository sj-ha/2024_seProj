package thisisjava;

class Meth13{
	static int cnt0 = 0; //1  
	int cnt3 = 0;
	
	void count01(int cnt1) {
		cnt0++;
		cnt1++;
		cnt3++;
		System.out.printf("%d,%d,%d\n", cnt0, cnt1, cnt3); // 1,11,1
	}
	
	void count02(int cnt2) {
		cnt0++;
		cnt2++;
		cnt3++;
		System.out.printf("%d,%d,%d\n", cnt0, cnt2, cnt3); // 2,21,1
	}
}

public class Cla13 {

	public static void main(String[] args) {
		Meth13 m1 = new Meth13();
		m1.count01(10);
		
		Meth13 m2 = new Meth13();
		m2.count02(20);
		
		Meth13 m3 = new Meth13();
		m3.count01(30);
		m3.count02(40);
	}

}
