package thisisjava;

class meth09{
	void sum(int x, int y) {
		System.out.println(x + y);
	}
	static void sub(int x, int y) {
		System.out.println(x - y);
	}
}

public class Cla09 {

	public static void main(String[] args) {
		int a = 20, b = 10;
//		m1의 경우 instance이기 때문에 메서드 변수를 생성해야 함.
		meth09 m1 = new meth09();
		m1.sum(a, b);
		meth09 m2 = new meth09();
		m2.sum(a, b);
//		허나 아래의 경우 static 메서드이기 때문에 따로 변수 선언 할 필요 없이 className인 meth09.sub가 가능하다. 
		meth09.sub(a, b);
	}

}
