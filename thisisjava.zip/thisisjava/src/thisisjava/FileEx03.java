package thisisjava;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

// C:\Temp\Sub03 폴더 생성 후 그 폴더에 menufile.txt 파일 생성, strArr에 있는 내용을 세로 방향으로 입력.
public class FileEx03 {

	public static void main(String[] args) throws IOException {
		String[] str = {"붕어빵", "어묵", "순대", "김밥", "몽쉘"};
		File dir = new File("C:\\temp\\Sub03");
		File file = new File(dir + "\\menufile.txt");
		Writer wr = new FileWriter(file);
		if (dir.exists() == false) {
			dir.mkdir();
		}
		if (file.exists() == false) {
			file.createNewFile();
		}
		
		int i = 0;
		for (String string:str) {
			System.out.println(string);
			String txt = (i+1) + string + "\n";
			wr.write(txt);
		}
		
		System.out.println("실행 성공");
	}

}
