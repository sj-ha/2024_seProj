package thisisjava;

public class Arr07 {

	public static void main(String[] args) {
		int[][] iArr01 = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
//		1
		System.out.println(iArr01[0][0]);
		System.out.println("=========================");

//		3, 4, 8  >  3
		System.out.println(iArr01[0][2]);
		System.out.println("=========================");

//		3
//		3
		System.out.println(iArr01.length);
		System.out.println(iArr01[0].length);
		System.out.println("=========================");

//		1 2 3
//		4 5 6
//		7 8 9
//		세로 방향으로 0-2까지 출력
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				System.out.print(iArr01[i][j] + " ");
			}
			System.out.println();
		}
		System.out.println("=========================");

//		
		for (int i = 0; i < iArr01.length; i++) {
			for (int j = 0; j < iArr01.length; j++) {
				System.out.print(iArr01[i][j] + " ");
			}
			System.out.println();
		}
		System.out.println("=========================");
	}

}
