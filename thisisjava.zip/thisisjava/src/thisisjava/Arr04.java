package thisisjava;

public class Arr04 {

	public static void main(String[] args) {
		int[] iArr1 = {10, 20, 30, 40, 50};
//		값을 그대로 가져오는 법
//		for (int i = 0; i < iArr1.length; i++) {
//			System.out.print(iArr1[i] + " ");
//		}
//		System.out.println();
//		
////		위의 방법을 좀 더 간편하게 쓰기 위한 방법
////		값들을 변수로 줘서 가져오는 법
//		for (int i : iArr1) {
//			System.out.print(i + " ");
//		}
		
//		for (int j = 0; j < iArr1.length; j++) {
//			System.out.print(j + ": ");
//			for (int i = 0; i < iArr1.length; i++) {
//				System.out.print(iArr1[i] + " ");
//			}
//		}
		
		
//		선생님 예시
//		10, 20, 30, 40, 50을 다른 방식으로 나타냄
		for (int i = 0; i < iArr1.length; i++) {
			System.out.println((i + 1) + " : " + iArr1[i]);
		}
		
		System.out.println();
		int iN = 1;
		for (int iA : iArr1) {
			System.out.println((iN++) + " : " + iA + " ");
		}
		
	}

}
