package thisisjava;

public class str04 {

	public static void main(String[] args) {
		String s1 = "Welcome to Korea";
		System.out.println(s1.length());
		System.out.println(s1.charAt(0));
		System.out.println(s1.charAt(5));
		System.out.println("===" + s1.charAt(7) + "===");
//		파이썬의 경우 역순서로 맨 뒤에서부터 인덱스를 찾는 방법인데 자바에선 되지 않는다.
//		System.out.println(s1.charAt(-1));
		
		System.out.println(s1.replace("K", "C"));
		System.out.println(s1.replace("Korea", "한국"));
		System.out.println(s1.replace("e", "2"));
		
//		0-8이전 까지 자르다. >> "Welcome "
		System.out.println(s1.substring(0, 8));
		
//		come to Kor
		System.out.println(s1.substring(3, 14));
		
//		c의 위치를 알고 싶을 때
		System.out.println(s1.indexOf("c"));

//		substring을 이용하여 해당 c와 r의 문자를 이용하여 출력할 때
		System.out.println(s1.substring(s1.indexOf("c"), s1.indexOf("r")));
		System.out.println(s1.substring(s1.indexOf("c"), s1.indexOf("r") + 1));
		
		String s2 = "사과,배,바나나,수박";
		String[] sArr = s2.split(",");
		for (int i = 0; i < sArr.length; i++) {
			
		}
		
	}

}
