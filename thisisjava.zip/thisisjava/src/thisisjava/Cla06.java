package thisisjava;

// 메서드 오버로딩
class Meth06{
	int Sum(int x, int y) {
		int ans = x + y;
		return ans;
	}
	String Sum(String x, String y) {
		String ans = x + y;
		return ans;
	}
	String Sum(String string, int i, int j) {
//		int ans = i + j;
//		return string + "결과 : " + ans;
//		선생님 예시
		return (string + "결과 : " + (i + j));
	}
}

public class Cla06 {

	public static void main(String[] args) {
		Meth06 m1 = new Meth06();
		System.out.println(m1.Sum(20, 10));
		System.out.println(m1.Sum("대한", "민국"));
//		결과 > 덧셈결과 : 34
		System.out.println(m1.Sum("덧셈", 30, 4));
	}

}
