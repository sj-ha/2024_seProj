package thisisjava;

public class str03 {

	public static void main(String[] args) {
		@SuppressWarnings("unused")
		String s1 = "KR";
		s1 = null;
		s1 = "EN";
		s1 = "CH";
		
	}

}
