package thisisjava;

public class Q1 {
	public static void main(String[] args) {
//		sqrt > 제곱근										  log10 > 10진수
		System.out.println((int)Math.sqrt(16) + (int)Math.log10(1000));
	}
}
