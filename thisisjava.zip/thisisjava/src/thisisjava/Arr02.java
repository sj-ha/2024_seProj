package thisisjava;

public class Arr02 {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		@SuppressWarnings("unused")
		int i1 = 100, i2 = 200;

//		같은 array여도 아래의 두 가지 방법으로 작성 가능하다.
//		+ iArr1과 iArr2의 경우 구조가 먼저 만들어지고 값이 들어갔기 때문에 주소가 달라진다.
		int[] iArr1 = { 10, 20, 30, 40 };
		int iArr2[] = { 10, 20, 30, 40 };

//		아래의 방법으로는 불가하다.
//		int[] iArr3 = {, , , };
//		방을 만들어 주는 방향으로 해야하나 아래 방법으로는 불가.
//		int[] iArr3 = [4];
//					  new = heap에 데이터가 들어갈 공간을 만들라는 의미
//					   + new의 경우 heap에 자리를 만들고 나면 그 자리에 0으로 초기화 값이 들어간다.
		int[] iArr3 = new int[4];

		iArr3[0] = 11;
		iArr3[1] = 22;
		iArr3[2] = 33;
		iArr3[3] = 44;
		for (int i = 0; i < 4; i++) {
			System.out.println(iArr3[i]);
		}

	}

}
