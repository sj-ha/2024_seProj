package thisisjava;

abstract class Ani33{
	String name;
//	추상메서드(선언부)
	abstract void cry();
//	일반메서드(선언부, 구현부)
	void shout() {
		System.out.println("으르렁");
	}
}

class Dog33 extends Ani33{

	@Override
	void cry() {
		System.out.println("멍멍");
	}
	void jump() {
		System.out.println("우다다");
	}
	
}

public class Cla33 {

	public static void main(String[] args) {
//		Ani33 a1 = new Ani33();
		Dog33 d1 = new Dog33();
		d1.cry();
		d1.shout();
		d1.jump();
	}

}
