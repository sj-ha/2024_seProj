package thisisjava;

public class Arr05 {

	public static void main(String[] args) {
//		사과, 배, 바나나
		String[] sArr1 = new String[3];
		System.out.println(sArr1);
		System.out.println(sArr1.length);
		System.out.println(sArr1[1]);
		System.out.println("=============");
		for (int i = 0; i < sArr1.length; i++) {
			System.out.println(sArr1[i]);
		}
		sArr1[0] = "사과";
		sArr1[1] = "배";
		sArr1[2] = "바나나";
		
		System.out.println("=============");
		for(String str : sArr1) {
			System.out.println(str);
		}
		
		System.out.println("=============");
		sArr1[2] = null;
		for(String str : sArr1) {
			System.out.println(str);
		}
	}

}
