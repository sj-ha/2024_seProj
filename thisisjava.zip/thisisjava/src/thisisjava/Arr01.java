package thisisjava;

public class Arr01 {

	public static void main(String[] args) {
		int i1 = 10;
		int i2 = 20;
		int i3 = 30;
		int i4 = 40;
		
//		int[] iArr1 = {10, 20, 30, 40};
//		[] > array로 index 번호를 갖게 된다.
		int[] iArr1 = {i1, i2, i3, i4};
		
		for (int i = 0; i < 4; i++) {
			System.out.println(iArr1[i]);
		}
		
		System.out.println("===========================");
//		sArr1 세로 방향 출력
		String[] sArr1 = {"사과", "배", "바나나"};
		for (int k = 0; k < 3; k++) {
			System.out.println(sArr1[k]);
		}
	}

}
