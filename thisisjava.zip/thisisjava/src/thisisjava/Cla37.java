package thisisjava;

class Tv37 {
	Tv37() {
		System.out.println("Tv37() 실행됨.");
	}

	@Override
	public String toString() {
		return "Tv37";
	}
}

class Product37<T, M> {
	private T kind;
	private M model;

	void setData(T kind, M model) {
		this.kind = kind;
		this.model = model;
	}

	T getKind() {
		return this.kind;
	}

	M getModel() {
		return this.model;
	}
}

class Car37 {
	Car37() {
		System.out.println("Car37() 실행됨.");
	}

	@Override
	public String toString() {
		return "Car37";
	}
}

public class Cla37 {
	public static void main(String[] args) {
		Product37<String, String> p00 = new Product37<>();
		p00.setData("Korea TV", "Smart TV");
		System.out.println(p00.getKind() + "," + p00.getModel());

		Product37<Tv37, String> p01 = new Product37<Tv37, String>();
		p01.setData(new Tv37(), "Smart TV");
		System.out.println(p01.getKind() + "," + p01.getModel());

		// Kind: Car37, Model: 디젤 => Car37,디젤
		Product37<Car37, String> p02 = new Product37<>();
		p02.setData(new Car37(), "디젤");
		System.out.println(p02.getKind() + "," + p02.getModel());
	}
}
