package thisisjava;

public class Q8 {

	public static void main(String[] args) {
//			0=8진수	0x=16진수
		char num = 0x06;
//							남은 자리를 0으로 채워라.
		System.out.printf("%04x", num << 2);
//					       16진수로	  왼쪽으로 2칸 밀어서 0으로 채움.
		
//		16진수는 2진수를 4자리씩 끊으며 빈자리는 0으로 채운다.
//		필기 p64 참고
	}

}
