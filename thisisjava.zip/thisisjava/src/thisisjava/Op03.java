package thisisjava;

public class Op03 {

//	참고 p93 연산자
//	&& & / || | 언어별로 같게 해석하는 것이 있으나 자바는 다르게 해석한다.

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		int i = 4, j = 3;
		System.out.println(i == j); // 비교연산자
		System.out.println(i > j);
		System.out.println(i != j);

		System.out.println("===========================");
		System.out.println(true && true);
		System.out.println(true && false);
		System.out.println(true & true);
		System.out.println(true & false);

		System.out.println("===========================");
		System.out.println(true || false);
		System.out.println(false || false);
		System.out.println(true | false);
		System.out.println(false | false);

		System.out.println("===========================");
//		**tip : 컴퓨터는 2진수로 던져줘야 속도가 빠르다.
//		논리연산자(&&) : true/false 값만 비교 함.
//		System.out.println(6 && 4);// 논리연산자
//		비트논리연산자(&) : 1/0 비트 변환 후 값을 비교함.
		System.out.println(6 & 4);// 비트논리연산자
		
//		논리연산자(&&) : true/false 값만 비교 함.
//		System.out.println(6 || 3);// 논리연산자
//		비트논리연산자(&) : 1/0 비트 변환 후 값을 비교함.
		System.out.println(6 | 3);// 비트논리연산자
		
		System.out.println("===========================");
//		8 > 비트 변환 시 1000
		int k = 8;
//		1000 >> 0100   >> 오른쪽으로 0을 채움, 비트로 한다면 4
		System.out.println(k >> 1);
//		1000 << 10000   >> 왼쪽으로 0을 채움, 비트로 한다면 16
		System.out.println(k << 1);
//		ㄴ결론 : 곱셈 하는 것 보다 >>|<< 하는 것이 더 빠르다.
//		

	}

}
