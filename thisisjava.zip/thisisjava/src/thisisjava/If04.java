package thisisjava;

import java.util.Scanner;

public class If04 {

	public static void main(String[] args) {
		String grade = "점수를 입력하세요.";
		System.out.println(grade);
		Scanner sc = new Scanner(System.in);
		int score = sc.nextInt();
//		boolean type으로도 가능하다는 예시
//		boolean score = sc.nextInt() >= 90;
		sc.close();
//		#################################### 중첩if문 practice
		if (score >= 90) {
			grade = "A";
			if (score >= 95) {
				grade += "+"; 
			} else {
				grade += "-"; 
			}
		} else if (score >= 80) {
			grade = "B";
			if (score >= 85) {
				grade += "+"; 
			} else {
				grade += "-"; 
			}
		} else if (score >= 70) {
			grade = "C";
			if (score >= 75) {
				grade += "+"; 
			} else {
				grade += "-";
			}
		} else {
			grade = "F";
		}
		System.out.println("점수 : " + score + "\n학점 : " + grade);
	}

}
