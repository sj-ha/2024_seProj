package thisisjava;

import java.util.Scanner;

public class Switch04 {
	public static void main(String[] args) {
//		String str1 = null;
		System.out.println("동서남북 중 입력해주세요.");
		Scanner sc = new Scanner(System.in);
		String str2 = sc.next();
		sc.close();
		System.out.println("입력한 값 : " + str2);

//		-> lambda 식을 쓰게 된다면 switch문에서 break;는 필요 없게 된다.
//		##################### lambda 식을 이용한 기본
//		switch (str2) {
////		case "동" -> str1 = "East";
//		case "동", "동쪽", "동녘" -> str1 = "East";
//		case "서" -> str1 = "West";
//		case "남" -> str1 = "North";
//		case "북" -> str1 = "South";
//		default -> str1 = "기타";
//		}

//		##################### lambda 식을 이용한 응용1
//		String str1 = switch (str2) {
//		case "동", "동쪽", "동녘" -> str1 = "East";
//		case "서" -> str1 = "West";
//		case "남" -> str1 = "North";
//		case "북" -> str1 = "South";
//		default -> str1 = "기타";
//		};

//		##################### lambda 식을 이용한 응용2
//		String str1 = switch (str2) {
//		case "동", "동쪽", "동녘" -> "East";
//		case "서" -> "West";
//		case "남" -> "North";
//		case "북" -> "South";
//		default -> "기타";
//		};

//		##################### lambda 식을 이용한 응용3
		String str1 = switch (str2) {
		case "동", "동쪽", "동녘" -> "East";
		case "서" -> "West";
		case "남" -> {
			String result = "South " + "방향";
			yield result;
		}
		case "북" -> "South";
		default -> "기타";
		};

		System.out.println(str1);
	}
}
