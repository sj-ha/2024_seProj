package thisisjava;

public class While02 {

	public static void main(String[] args) {
		int i = 0;
		while (true) {
			if (i >= 100) {
				break;
			}
			i++;
//			1~100 홀수만 출력
//			if (i % 2 == 0) {
//				continue  =>  앞으로 이동해서 for문을 실행
//				continue;
//			}
			
//			5의 배수만 출력
			if (i % 5 != 0) {
//				continue  =>  앞으로 이동해서 for문을 실행
				continue;
			}
			System.out.println(i);
			
			
//			#################################값이 없어도 무한반복
//			for (;;) {
//				System.out.println(i++);
//				if (i >= 100) {
//					break;
//				}
//			}
//			#################################
		}
	}

}
