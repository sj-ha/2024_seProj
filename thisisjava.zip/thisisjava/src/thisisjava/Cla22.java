package thisisjava;

class Vehicle22 {

	void start() {
		System.out.println("출발");
	}

	void move() {
		System.out.println("이동");
	}

	void stop() {
		System.out.println("멈춤");
	}
}

class Car22 extends Vehicle22 {
//	static final : 공용 공간의 불변 값.
//			변수 앞에 final이 붙으면 상수 : 값이 바뀌지 않음.
//	final method > 오버라이딩 불가
//	final class > 상속 불가
	static final int Normal = 1;
	static final int Accel = 2;
	static final int Slow = 3;

	int moveMode = Normal;

	void move() {
		if (moveMode == Normal) {
			super.move();
		} else if (moveMode == Accel) {
			System.out.println("빠른 이동");
		} else {
			System.out.println("천천히 이동");
		}
	}
}

public class Cla22 {
	public static void main(String[] args) {
		Car22 c1 = new Car22();
		c1.start();
		c1.move();
		c1.moveMode = Car22.Accel;
		c1.move();
		c1.moveMode = Car22.Slow;
		c1.move();
		c1.stop();
	}

}
