package thisisjava;

class A20 {
	String name = "이 름";

	void cry() {
		System.out.println("으 앙");
	}
}

class Dog20 extends A20 {
	String name = "해 피";

//	아래 애노테이션의 의미는 제대로 상속을 받고 있는지, 오타는 없는지 확인할 수 있다.
	@Override
	void cry() {
		System.out.println("멍 멍");
	}
}

class Cat20 extends A20 {
	String name = "아 치";

	@Override
	void cry() {
		System.out.println("야 옹");
	}
}

class Duck20 extends A20 {
	String name = "도 트";

	@Override
	void cry() {
		System.out.println("꽥 꽥");
	}
}

public class Cla20 {
	public static void main(String[] args) {
		Dog20 dog = new Dog20();
		System.out.println(dog.name);
		dog.cry();

		Cat20 cat = new Cat20();
		System.out.println(cat.name);
		cat.cry();

		Duck20 duck = new Duck20();
		System.out.println(duck.name);
		duck.cry();
	}

}
