package thisisjava;

import java.util.Scanner;

// class가 띄워짐.
public class If01 {
//	참조 p.112 if 조건문
	
//	cpu가 main을 찾게 되고 실행 되고 (String[] args) 기본 변수가 있음.
	public static void main(String[] args) {
//		조건식 ? true : false
		System.out.println("숫자를 입력하세요.");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		String ans = null;
		if ((n % 2) == 0) {
			ans = "짝수";
		} else {
			ans = "홀수";
		}
		System.out.println(ans);
		sc.close();
	}

}
