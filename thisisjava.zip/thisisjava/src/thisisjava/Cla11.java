package thisisjava;

class Meth11{
	static int count01 = 0;
	int count02 = 0;
}

public class Cla11 {

	public static void main(String[] args) {
//		static과 instance를 어떻게 활용해서 쓰는지에 대한 예시.
		/////////////////////////////////////
		Meth11 m = new Meth11();
		Meth11.count01 += 10;
		m.count02 += 10;
		/////////////////////////////////////
		
//		10
		System.out.println(Meth11.count01);
//		10
		System.out.println(m.count02);
	}

}
