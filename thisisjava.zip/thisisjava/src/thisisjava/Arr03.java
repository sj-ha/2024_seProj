package thisisjava;

public class Arr03 {

	public static void main(String[] args) {
		int[] iArr1 = new int[10];
//		for (int i = 0; i < 10; i++) {
//			System.out.println(iArr1[i]);
//		}
		
//		10, 20, ,,, 100까지의 숫자를 iArr1에 for문을 이용해서 입력해주세요
//		for (int i = 0; i < 10; i++) {
//			iArr1[i] = ((i + 1) * 10);
//			System.out.println(iArr1[i]);
//		}
//		
//		for (int i = 0; i < iArr1.length; i++) {
//			iArr1[i] = ((i + 1) * 10);
//			System.out.println(iArr1[i]);
//		}
		
		for (int i = 0; i < iArr1.length; i++) {
//			10,9,8,7,,,,, 3,2,1 역순으로 나타내라.
			iArr1[i] = ((10 - i));
//			100,90,80,70,,,,, 30,20,10 역순으로 나타내라.
			iArr1[i] = ((10 - i) * 10);
			System.out.println(iArr1[i]);
		}
		
	}

}
