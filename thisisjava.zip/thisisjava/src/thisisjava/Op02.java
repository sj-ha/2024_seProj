package thisisjava;

public class Op02 {

	public static void main(String[] args) {
//		증감연산자 : 연산자의 위치로 인해서 앞에 붙었는지 뒤에 붙었는지 알 수 있다.
//		앞에 기호가 있게 되면 연산 전 증감
//		뒤에 기호가 있게 되면 연산 후 증감

		// ++ , --
		int a = 10;
		int b = --a;
		System.out.println(a); //
		System.out.println(b); //
		System.out.println("==========================");

		int c = a--;
		System.out.println(a); //
		System.out.println(c); //
		System.out.println("==========================");

		int d = ++a;
		System.out.println(a); //
		System.out.println(d); //
		System.out.println("==========================");

		int e = a++;
		System.out.println(a); //
		System.out.println(e); //
	}

}
