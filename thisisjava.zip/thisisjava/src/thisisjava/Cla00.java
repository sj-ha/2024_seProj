package thisisjava;

class Book00 {
	String title;// 책명
	String author;// 저자
	int price;// 가격
}

public class Cla00 {
	public static void main(String[] args) {
		Book00 b1 = new Book00();
		b1.title = "자바";
		b1.author = "홍길동";
		b1.price = 30000;

		System.out.println(b1.title);
		System.out.println(b1.author);
		System.out.println(b1.price);

		Book00 b2 = new Book00();
		b2.title = "소공";
		b2.author = "김은비";
		b2.price = 40000;

		System.out.println(b2.title);
		System.out.println(b2.author);
		System.out.println(b2.price);
	}

}
