package thisisjava;

import java.util.Scanner;

public class if08 {

	public static void main(String[] args) {
		
		System.out.println("국어 점수를 입력하세요.");
		Scanner sc = new Scanner(System.in);
		int iKr = sc.nextInt();
		System.out.println("영어 점수를 입력하세요.");
		int iEn = sc.nextInt();
		System.out.println("수학 점수를 입력하세요.");
		int iMt = sc.nextInt();
		sc.close();
		
//		총점
		int iTotal = iKr + iEn + iMt;
//		평균
		double dAvg = iTotal / 3.0;
		
//		등급 변수
		String grade = null;
//		과목 낙제 변수
		String str = null;
//		과목 중 하나라도 60점 미만이라면 과목 낙제
		if ((iKr < 60) || (iEn < 60) || (iMt < 60)) {
			str = "과목 낙제";
		} else {
//		평균 점수가 90이상 우수, 80이상 보통, 70이상 부족, 그 외 평균 낙제
			if (dAvg >= 90) {
				grade = "우수";
			} else if(dAvg >= 80){
				grade = "보통";
			} else if(dAvg >= 70){
				grade = "부족";
			} else {
				grade = "평균 낙제";
			}
			str = "과목 통과";
			System.out.println("\n결과: " + str + ", 등급: " + grade);
		}
		
		
		System.out.printf("국어: %d, 영어: %d, 수학: %d", iKr, iEn, iMt);
		System.out.printf("\n총점: %d, 평균: %.2f", iTotal, dAvg);
	}

}
