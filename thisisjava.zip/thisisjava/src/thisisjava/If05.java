package thisisjava;

import java.util.Scanner;

public class If05 {
	public static void main(String[] args) {
		String str1 = null;
		System.out.println("동서남북 중 입력해주세요.");
		Scanner sc = new Scanner(System.in);
		String str2 = sc.next();
		sc.close();
		System.out.println("입력한 값 : " + str2);

		if ("동".equals(str2)) {
			str1 = "East";
		} else if("서".equals(str2)) {
			str1 = "West";
		} else if("남".equals(str2)) {
			str1 = "North";
		} else if("북".equals(str2)) {
			str1 = "South";
		} else {
			str1 = "기타";
		}
		System.out.println(str1);
	}
}
