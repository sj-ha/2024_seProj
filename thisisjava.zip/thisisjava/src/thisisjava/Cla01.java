package thisisjava;

public class Cla01 {

	public static void main(String[] args) {
		// Book01 데이터 타입을 가져다 사용.
		Book01 b1 = new Book01("기사", "양정열", 50000);
		b1.pBook();
//		b1.title="기사";b1.author="양정열";b1.price=50000;
//		b1.pBook();
		Book01 b2 = new Book01();
		b2.title = "자바";
		b2.author = "Alice";
		b2.price = 60000;
		b2.pBook();
	}

}
