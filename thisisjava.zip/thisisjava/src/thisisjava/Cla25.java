package thisisjava;

class A25{
	int a = 200;
}

class B25 extends A25{
	int b = 100;
}

public class Cla25 {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
//		참조형의 변환
		A25 z1 = new A25();
		B25 z2 = new B25();
		A25 z3 = new B25();
//		에러
//		자식() = 부모() O가능  but  부모() = 자식() X불가능
//		B25 z4 = new A25();
//		위의 에러를 아래로 바꾼다면 문법상으로는 에러가 없으나 데이터 상으로는 ClassCastException이 뜬다.
		B25 z4 = (B25) new A25();
		
		
//		아래는 값형의 변환
		short s1 = 10;
		int i1 = s1;
		int i2 = 20;
//					자동 형 변환 / 명시적 형 변환
		short s2 = (short) i2;
	}

}
