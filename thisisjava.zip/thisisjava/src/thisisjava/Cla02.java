package thisisjava;

class Book02 {
	String title;
	String author;
	int price;

	Book02() {
		System.out.println("Book02() 실행");
	}

	Book02(String title, String author, int price) {
		System.out.println("Book02(t,a,p) 실행");
		this.title = title;
		this.author = author;
		this.price = price;
	}

	void pBook() {
		System.out.println(this.title + "," + this.author + "," + this.price);
	}
}

public class Cla02 {
	public static void main(String[] args) {
		Book02 b1 = new Book02();
		b1.pBook();
		Book02 b2 = new Book02("APT", "로제", 1000);
		b2.pBook();
	}

}
