package thisisjava;

// JAVA에서 부모로 상속 받은 선언부를 그대로 따라야 한다. 자식 메서드에서 선언할 때 부모보다 작아질 수 없다.
class A29 {
	void meth01() {

	}
}

class B29 extends A29 {
	@Override
	/*private*/ void meth01() {

	}
}

public class Cla29 {

	public static void main(String[] args) {

	}

}
