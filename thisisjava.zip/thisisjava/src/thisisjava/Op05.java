package thisisjava;

import java.util.Scanner;

public class Op05 {

	public static void main(String[] args) {
//		(조건식) ? true : false
//		int n = 7;
////		n이 2로 나눈 나머지가 0이면 짝수, 1이면 홀수
////				(n이 2로 나눈 나머지가 0이면) ? "짝수" : "홀수"
//		
//		String ans = ((n%2) == 0 ) ? "짝수" : "홀수";
//		System.out.println(ans);
		
		
//		########################################스캐너를 이용한 식
//		System.out.println("숫자 입력 => ");
//		Scanner sc = new Scanner(System.in);
//		int n = sc.nextInt();
//		String ans = ((n%2) == 0 ) ? "짝수" : "홀수";
//		System.out.println(ans);
//		sc.close();

//		########################################스캐너를 이용한 식
		System.out.println("숫자 입력 => ");
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		String ans = ((n) >= 10 ) ? "큰 수" : "작은 수";
		System.out.println(ans);
		sc.close();
		
	}

}
