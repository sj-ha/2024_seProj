package thisisjava;

class Meth12{
	static int cnt0 = 0;
	
	static void count01() {
		int cnt1 = 0;
		cnt0++;
		cnt1++;
		System.out.printf("%d,%d\n", cnt0, cnt1);
	}
	
	void count02() {
		int cnt2 = 0;
		cnt0++;
		cnt2++;
		System.out.printf("%d,%d\n", cnt0, cnt2);
	}
}

public class Cla12 {

	public static void main(String[] args) {
		Meth12.count01();
		
		Meth12 m = new Meth12();
		m.count02();
	}

}
