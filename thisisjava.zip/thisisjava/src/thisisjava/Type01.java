package thisisjava;

public class Type01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			short a1 = 10;
			int	a2 = 20;
			int	a3 = a1;
			short a4 = (short) a2;
			
			System.out.println(a1);
			System.out.println(a2);
			System.out.println(a3);
			System.out.println(a4);
	}

}
