package thisisjava;

class Book04{
	String title;
	String author;
	int price;
	
	Book04(String title, String author, int price){
		this.title = title;
		this.author = author;
		this.price = price;
//		선생님 예시
		System.out.printf("%s, %s, %d", this.title, this.author, this.price);
	}
}

public class Cla04 {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Book04 b1 = new Book04("자바", "Tom", 30000);
//		System.out.printf("%s, %s, %d", b1.title, b1.author, b1.price);
	}

}
