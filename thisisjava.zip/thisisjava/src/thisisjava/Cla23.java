package thisisjava;

// final 설명 집합
class A23{ 
	final int a=200;
	final void method01() { System.out.println("A23.method01()"); }
}
final class B23 extends A23{ 
	int b=100; 
	//void method01() { System.out.println("B23.method01()"); }
}
//class C23 extends B23{ }

public class Cla23 {
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		B23 b1 = new B23();
//		a가 final로 선언됐기 때문에 값 수정 불가
//		b1.a = 300;
	}

}
