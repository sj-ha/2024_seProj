package thisisjava;

import java.util.Scanner;

public class Type08 {

	public static void main(String[] args) {
		System.out.println("이름 입력 => ");
		Scanner sc = new Scanner(System.in);
		String name = sc.next();
		System.out.println(name + " 님 안녕하세요.");
		sc.close();
	}

}
