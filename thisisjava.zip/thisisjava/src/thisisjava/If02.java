package thisisjava;

import java.util.Scanner;

public class If02 {

	public static void main(String[] args) {
		System.out.println("점수를 입력해주세요.");
		Scanner sc = new Scanner(System.in);
		int score = sc.nextInt();
		String grade = null;
		if (score >= 90) {
			grade = "우수";
		} else if (score >= 80) {
			grade = "보통";
		} else if (score >= 70) {
			grade = "부족";
		} else {
			grade = "낙제";
		}
		System.out.println("점수 : " + score + "\n등급 : " + grade);
		sc.close();
	}

}
