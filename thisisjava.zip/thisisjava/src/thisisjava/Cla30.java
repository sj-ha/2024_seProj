package thisisjava;

class Cla31 {
	public static void main(String[] args) {
		System.out.println("Cla30-main() 실행");
	}

	static void test01() {
		System.out.println("Cla31-test01() 실행");
	}

	void test02() {
		System.out.println("Cla31-test02() 실행");
	}
}

public class Cla30 {

	public static void main(String[] args) {
		System.out.println("Cla30-main() 실행");
		Cla31.test01();
		Cla30.test01();
		test01();
		Cla31 c31 = new Cla31();
		c31.test02();
		Cla30 c30 = new Cla30();
		c30.test02();
	}

	static void test01() {
		System.out.println("Cla30-test01() 실행");
	}

	void test02() {
		System.out.println("Cla30-test02() 실행");
	}

}
