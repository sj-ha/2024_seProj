package thisisjava;

public class Type04 {

	public static void main(String[] args) {
		char a1 = 'A';  // <- 01000001 로 저장
//		A
		System.out.println(a1);
//		65
		System.out.println((int)a1);
//		1000001
		System.out.println(Integer.toBinaryString(a1));
//		101
		System.out.println(Integer.toOctalString(a1));
//		41
		System.out.println(Integer.toHexString(a1));
		
		char a2 = 65;
//		A
		System.out.println(a2);
		char a3 = 0101;
//		A
		System.out.println(a3);
		char a4 = 0x0041;
//		A
		System.out.println(a4);
	}

}
