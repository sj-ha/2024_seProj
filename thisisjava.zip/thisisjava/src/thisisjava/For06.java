package thisisjava;

public class For06 {

	public static void main(String[] args) {
		// 1 ~ 10까지 합산 결과는?
//		시작점:1  int i = 1;
//		끝점:10  i <= 10;
//		스텝:1씩 증가 i++;
//		처리:누적 변수 선언 +=   sum += i;

		int sum = 0;
		for (int i = 1; i <= 10; i++) {
			sum += i;
		}
		System.out.println("합계: " + sum);
	}

}
