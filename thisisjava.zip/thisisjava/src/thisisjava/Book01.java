package thisisjava;

public class Book01 {
	// 멤버 필드
	String title;// 책명
	String author;// 저자
	int price;// 가격
	// 멤버 생성자

	Book01() {
	}

	Book01(String t, String a, int p) {
		title = t;
		author = a;
		price = p;
	}

	// 멤버 메소드
	void pBook() {
		System.out.println(title + "," + author + "," + price);
	}
}
