package thisisjava;

// 제네릭<T>  >>  형 변환이 자유롭다.
class Gen01<kr> {
	private kr name;

	kr getName() {
		return name;
	}

	void setName(kr name) {
		this.name = name;
	}
}

class Gen02<T> {
	void sum(T i, T j) {
		System.out.println(i + "" + j);
	}
}

class Gen03<A, B> {
	public void sum(A string, B j) {
		System.out.println(string + ", " + j);
	}
}

class Gen04<K, T> {
	private K x;
	private T y;

	public String getList() {
		return this.x + " : " + this.y;
	}

	public void setList(K i, T j) {
		this.x = i;
		this.y = j;
	}
}

class Gen05<K, T> {
	private String x;
	private K y;
	private T z;
	public String getList() {
		return x + " : " + y + ", " + z;
	}
	public void setList(String i, K j, T k) {
		x = i;
		y = j;
		z = k;
	}
}

public class Cla36 {

	public static void main(String[] args) {
//		기본 제네릭 연습
		Gen01<String> g1 = new Gen01<String>();
		g1.setName("Tom");
		System.out.println(g1.getName());

		Gen01<Integer> g2 = new Gen01<Integer>();
		g2.setName(2024);
		System.out.println(g2.getName());

		Gen01<Boolean> g3 = new Gen01<Boolean>();
		g3.setName(true);
		System.out.println(g3.getName());

		Gen01<Double> g4 = new Gen01<Double>();
		g4.setName(2025D);
		System.out.println(g4.getName());
		System.out.println("========================================");

//		제네릭 예제1  Gen02<T>
		Gen02<Integer> g02 = new Gen02<Integer>();
		g02.sum(20, 10);
		Gen02<String> g03 = new Gen02<String>();
		g03.sum("대한", "민국");

		Gen02<Integer> g04 = new Gen02<>();
		g04.sum(30, 40);
		Gen02<String> g05 = new Gen02<>();
		g05.sum("JAVA", "입문");

		Gen02<Integer> g06 = new Gen02<Integer>();
		g06.sum(30, 40);
		Gen02<String> g07 = new Gen02<String>();
		g07.sum("JAVA", "입문");
		System.out.println("========================================");

//		제네릭 예제2  Gen03<A, B>
		Gen03<String, Integer> g08 = new Gen03<>();
		g08.sum("서울", 2024);
		Gen03<Integer, String> g09 = new Gen03<>();
		g09.sum(2024, "한국");
		Gen03<Integer, Integer> g10 = new Gen03<>();
		g10.sum(2024, 1205);
		System.out.println("========================================");

//		제네릭 예제3
		Gen04<String, Integer> gen04 = new Gen04<String, Integer>();
		gen04.setList("홍길동", 20);
		System.out.println(gen04.getList());
		Gen04<Integer, String> gen04_1 = new Gen04<Integer, String>();
		gen04_1.setList(30, "Tom");
		System.out.println(gen04_1.getList());
		System.out.println("========================================");

		Gen05<Integer, String> gen05 = new Gen05<Integer, String>();
		gen05.setList("홍길동", 20, "남성");
		System.out.println(gen05.getList());
		Gen05<String, Integer> gen05_1 = new Gen05<String, Integer>();
		gen05_1.setList("제인", "여성", 30);
		System.out.println(gen05_1.getList());
		System.out.println("========================================");
		
		
	}

}
