package thisisjava;

public class Arr09 {

	public static void main(String[] args) {
		@SuppressWarnings("unused")
		int[] iArr00 = new int[4];

		int[][] iArr01 = new int[3][];
		iArr01[0] = new int[4];
		iArr01[1] = new int[2];
		iArr01[2] = new int[3];

		for (int i = 0; i < iArr01.length; i++) {
			for (int j = 0; j < iArr01[i].length; j++) {
				System.out.printf("%d ", iArr01[i][j]);
			}
			System.out.println();
		}
	}

}
