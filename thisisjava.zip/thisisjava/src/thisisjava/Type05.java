package thisisjava;

public class Type05 {

	public static void main(String[] args) {
//		Heap 대표 예시 > 짜장면 집 ~
		
//		Exception in thread "main" java.lang.Error: Unresolved compilation problem: 
//			The local variable s1 may not have been initialized
//
//			at thisisjava.type05.main(type05.java:7)
//		주소 값이 없어서 생긴 에러
//		String s1;
//		System.out.println(s1);
		
		String s1 = null;
//		null
		System.out.println(s1);
		
		s1 = "서울";
//		서울
		System.out.println(s1);
		
		s1 = null;
//		null
		System.out.println(s1);
//		heap에 저장된 값이 연결된 데이터가 없을 경우 garbage collector로 인해 삭제됨.
		
//		String s2 = "'사랑'합니다.";
////		선언 후 다시 값을 넣게 되면 주소가 바뀌게 된다.
//		s2 = "'사랑'합니다.";
		
		String s2 = "사랑";
		System.out.println(s2);
		s2 = "썰렁";
		System.out.println(s2);
		
//		이스케이프 참조 p52
		String s3 = "사랑";
		s3 = "\"사랑\"합니다.";
		s3 = "2024년 11월 12일. 날씨 좋아요 "
				+ "그래서, 맛있는 점심을 먹고 싶어요";
		System.out.println(s3);
//		new line ex
		s3 = "2024년 11월 12일. \n 날씨 좋아요 그래서, 맛있는 점심을 먹고 싶어요";
		System.out.println(s3);
		
//		sysout.print의 경우 옆으로 쭉 나열됨.
		System.out.print("안녕");
		System.out.print("하세요\n");
		System.out.print("안녕");
		System.out.print("하세요");
		
	}

}
