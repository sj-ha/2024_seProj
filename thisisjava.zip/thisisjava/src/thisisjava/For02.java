package thisisjava;

public class For02 {

	public static void main(String[] args) {
//		1. 0 ~ 4까지 가로 출력
//		선생님 예시
//		for (int i = 0; i < 5; i++) {
//			System.out.print(i + " ");
//		}
		for (int i = 0; i <= 4; i++) {
			System.out.print(i + " ");
		}
		
		System.out.println();
//		2. 2 4 6 8 10
//		선생님 예시
//		for (int j = 2; j <= 10; j + 2) {
//			System.out.print(j + " ");
//		}
		
		System.out.println();
		for (int j = 2; j <= 10; j++) {
			if(j % 2 == 0) {
				System.out.print(j + " ");
			}
		}
		
		System.out.println();
//		3. -2 -1 0 1 2
		for (int k = -2; k <=2 ; k++) {
			System.out.print(k + " ");
		}
		
		
		
//		##################################구구단 예시
		for (int m = 0; m <= 30; m += 3) {
			System.out.print(m + " ");
		}
//		##################################
	}
}
