package thisisjava;

interface iCalc35{
	int Sum(int x, int y);
	int Sub(int x, int y);
}

interface iTest35{
	void Hi();
}

interface iSum35{
	int Sum(int x, int y);
}

interface iString1{
	String test();
}

interface iHello1{
	String Hi();
}

public class Cla35 {

	public static void main(String[] args) {
		iCalc35 i1 = new iCalc35() {
			
			@Override
			public int Sum(int x, int y) {
				return x + y;
			}
			
			@Override
			public int Sub(int x, int y) {
				return x + y;
			}
		};
		System.out.println(i1.Sub(20, 40));
		System.out.println(i1.Sum(30, 10));
		
		iTest35 t1 = new iTest35() {
			@Override
			public void Hi() {
				System.out.println("기본 예제");
			}
		};
		t1.Hi();
		
//		위의 방식이 기본이며, 아래가 람다식으로 표현한 것이다.
		iTest35 t2 = () -> {
			System.out.println("람다식 예제");
		};
		t2.Hi();
		
		iSum35 s1 = (x, y) -> x + y;
		System.out.println(s1.Sum(30, 40));
		
//		선생님 예제
		iSum35 s100 = (int x, int y) -> {
			return x + y;
		};
//		위의 더 간단한 식
		System.out.println(s100.Sum(10, 20));
		iSum35 s1001 = (x, y) -> {
			return x + y;
		};
		System.out.println(s1001.Sum(80, 20));
//		위의 더 간단한 식
		iSum35 s10011 = (x, y) -> x + y;
		System.out.println(s10011.Sum(50, 20));
//		익명 객체 람다식
		iSum35 s100111 = new iSum35() {
			public int Sum(int x, int y) {
				return x + y;
			}
		};
		System.out.println(s100111.Sum(90, 40));
		
		
//		String 람다식
		iString1 str1 = () -> "ab";
		System.out.println(str1.test());
		
	}

}
