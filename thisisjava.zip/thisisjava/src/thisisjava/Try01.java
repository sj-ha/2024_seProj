package thisisjava;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Try01 {

//	기능사 시험 문제
	public static void main(String[] args) {
//		ArithmeticException error
//		System.out.println("숫자 하나 입력 => ");
//		Scanner sc = new Scanner(System.in);
//		int i1 = sc.nextInt();
//		int i2 = 100 / i1;
//		
//		sc.close();
//		System.out.println(i2);
		
//		##############################
		try {
			System.out.println("숫자 하나 입력 => ");
			Scanner sc = new Scanner(System.in);
			int i1 = sc.nextInt();
			int i2 = 100 / i1;
			
			sc.close();
			System.out.println(i2);
		} catch (ArithmeticException e) {
			System.err.println(e);
			System.err.println("0 입력으로 인한 에러.\n재실행 바랍니다.");
		} catch (InputMismatchException e) {
			System.err.println(e);
			System.err.println("문자 입력으로 인한 에러.\n재실행 바랍니다.");
//			finally 정상적이든 비정상적이든 항상 실행
		} finally {
			System.out.println("=========항상 실행=========");
		}
	}

}
