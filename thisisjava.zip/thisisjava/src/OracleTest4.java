import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class OracleTest4 {
	public static void main(String args[]) {
		Connection conn = null; // DB연결된 상태(세션)을 담은 객체
		PreparedStatement pstm = null; // SQL 문을 나타내는 객체
		// ResultSet rs = null; // 쿼리문을 날린것에 대한 반환값을 담을 객체

		try {
			// SQL 문장을 만들고 만약 문장이 질의어(SELECT문)라면
			// 그 결과를 담을 ResulSet 객체를 준비한 후 실행시킨다.
//			String query = "insert into dept2(deptno,dname,loc) values(?,?,?)";
			String query = "delete from dept2 where deptno = ?";

			conn = DBConnection.getConnection();
			pstm = conn.prepareStatement(query);
			// rs = pstm.executeQuery(); // <- select

//			pstm.setInt(1, 50);
//			pstm.setString(2, "IT");
//			pstm.setString(3, "Jeju");
			
//			pstm.setString(1, "Seoul");
//			pstm.setString(2, "AS");
			pstm.setInt(1, 50);

			int rows = pstm.executeUpdate(); // <- insert,update,delete
			System.out.println(rows + "개 행이 처리됨.");

		} catch (SQLException sqle) {
			System.out.println("Delete 문에서 예외 발생");
			sqle.printStackTrace();

		} finally {
			// DB 연결을 종료한다.
			try {
				// if ( rs != null ){rs.close();}
				if (pstm != null) {
					pstm.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e) {
				throw new RuntimeException(e.getMessage());
			}

		}
	}
}
