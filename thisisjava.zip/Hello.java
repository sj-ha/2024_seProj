// 클래스
class Hello{
	// 함수
	public static void main(String[] args){
		// 처리
		System.out.println("Hello World~~~~");
/*
여러 줄 주석
*/
	}
}