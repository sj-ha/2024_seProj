#include <stdio.h>

int main()
{
    char a[] = {'1', 'B', 'C', 'D', 'E'};
    char *p;
    // p = c의 주소
    p = &a[2];
    // *p = C  *(C의 주소 - 2) 1?
    // C1
    // ***참고  *(p - 2) : ()괄호 먼저 계산, char = 1byte로 -2는 2byte이기 때문에 a[0] 주소로 가게 되며, 앞에 *가 붙기 때문에 a[0]의 값인 1을 가져온다.
    printf("%c%c", *p, *(p - 2));
    // 참고printf
    printf("%c%c %p %p", *p, *(p - 2), p, (p - 2));
    return 0;
}