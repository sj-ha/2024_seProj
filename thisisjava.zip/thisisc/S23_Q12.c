#include <stdio.h>

int main(){
    // &  >> 비트연산자
    // 2의보수 > 1. 2진수 > 2. 반전 > 3. +1 > 4. AND(*)곱하기 연산
    printf("%d", -5 & 7);
    return 0;
}