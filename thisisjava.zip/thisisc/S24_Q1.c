#include <stdio.h>

// c언어에서는 -> 람다식 지원하지 않음.

int main(){
    int i, j;
    for (i = 2; i <= 4; i++){
        for (j = 0; j <= 7; j++)
        {
        }
        
    }
    printf("%d x %d = %2d", j, i, i * j);
}
