#include <stdio.h>

// 순서도 답 >> a MOD 3 = 0 이면서(AND) a MOD 7 = 0

int main(){
    int a;
    printf("정수 입력 : ");
    scanf("%d", &a);
    // a % 3 + a % 7 = 0
    if ((a % 3 == 0) && (a % 7 == 0))
    {
        printf("3의 배수이면서 7의 배수임\n");
    }
    else
    {
        printf("3의 배수이면서 7의 배수가 아님");
    }
    
}
