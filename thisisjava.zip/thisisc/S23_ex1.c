#include <stdio.h>

int main()
{
    int i, j;
    float aa;
    char cc, dd[10];

    printf("변수 입력:\n");
    
    printf("10진수와 8진수를 각각 입력하시오: ");
    scanf("%d %o", &i, &j);
 
    printf("실수를 입력하시오: ");
    scanf("%f", &aa);

    printf("문자를 입력하시오: ");
    scanf(" %c", &cc);

    printf("문자열을 입력하시오: ");
    scanf(" %9s", dd);

    printf("\n출력:\n");
    printf(" i = %d \n", i);
    printf(" j (octal) = %o \n", j);
    printf(" aa = %f \n", aa);
    printf(" cc = %c \n", cc);
    printf(" dd = %s \n", dd);

    
}
