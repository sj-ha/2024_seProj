#include <stdio.h>

// 문제 : 다음 C언어로 구현된 프로그램에 "Korea50"을 입력하였을 때 그 실행 결과를 써라.
int main(){
    int len = 0;
    // ** c는 stack에 만들어진다.
    // c의 경우 그냥 배열만 선언할 경우 메모리 안에 쓰레기 값들이 들어간다.
    char str[50];
    // 입력 받아서 변수에 담는다.
    gets(str);
    for (int i = 0; str[i]; i++)
    {
        len += 1;
    }
    printf("%d", len);
}