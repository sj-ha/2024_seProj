#include <stdio.h>

int main(){
    printf("%d\n", sizeof(12.3));
    printf("%d", sizeof(char));
    return 0;
}