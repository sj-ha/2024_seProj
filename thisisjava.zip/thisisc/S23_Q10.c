#include <stdio.h>

int main(){
    int num = 1640;
    printf("%d", num >> 3);
}