#include <stdio.h>

int main(){
    int num1 = 16, num2 = 80;
    //             16 > 80  false              16 ^ 80    ^xor:비트연산자 >> 2진수로 바꾼 후 xor 연산
    //                                      64 32 16 8 4 2 1
    //                                      
    printf("%d", num1 > num2 ? num1 & num2 : num1 ^ num2);
}