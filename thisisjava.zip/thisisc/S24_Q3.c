#include <stdio.h>

int main(){
    double num = 0.01;
    double res = 0;
    int cnt = 0;
    while (cnt < 100)
    {
        // 0.01  
        res += num;
        // 1
        cnt++;
    }
    // res = 1.0
    printf(res == 1 ? "true" : "false");
    
    return 0;
}
// 형이 달라서 false