#include <stdio.h>

int main(void){
    int i = 200;
    float a = 123.456f;

    i = (int)a;
    // 123.456f > 6에서 반올림 돼 123.46
    printf("%d, %3.2f", i, a);
    return 0;
}