#include <stdio.h>

int main(){
    printf("%d", sizeof(12));
    return 0;
}
