#include <stdio.h>
#include <math.h>

int main()
{
    // int ans = pow(2, ceil(M_PI));
    // printf("%d", ans);
}
