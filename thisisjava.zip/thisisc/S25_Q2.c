#include <stdio.h>

// 문제 : 다음은 좌회전 ROL(Rotate of Left)을 구현한 C언어 프로그램. 빈 칸의 명령을 쓰시오.
int main(){
    int i, a[5], temp;
    // 0 ~ 4
    for ( i = 0; i < 5; i++)
    {
        a[i] = i + 1;
        printf("%d", a[i]);
    }
    printf("\n");
    temp = a[0];
    // 0 ~ 3
    for ( i = 0; i < 4; i++)
    {
        a[i] = a[i + 1];
    }
    // 아래의 (   )가 문제
    // (   ) = temp;
    a[i] = temp;
    // 0 ~ 4
    for ( i = 0; i < 5; i++)
    {
        printf("%d", a[i]);
    }
    
}

// 결과
// 12345
// 23451