#include <stdio.h>

// c에서는 true false를 엄하게 보지 않는다. true=1, false=0

int main()
{
    int a = 2, b = 3, c, d, e;
//  c = 2 > 3 && 3 > 2  false
    c = a > 3 && b > 2;
    //  2 > 3 || 3 > 2  true
    d = a > 3 || b > 2;
    // e = !0  true
    e = !c;

    printf("c: %d, d: %d, e:%d\n", c, d, e);
}
