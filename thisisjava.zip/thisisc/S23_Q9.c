#include <stdio.h>

int main(){
    // 
    char str[128];
    // 문제 아래 빈칸
    // scanf(());
    scanf("%s", str);
    printf("%s", str);
}