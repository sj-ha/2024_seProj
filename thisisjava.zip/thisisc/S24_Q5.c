#include <stdio.h>

int main(){
    int num = 1;
    for (int i = 1; ; i++)
    {
        num = num * i;
        // 1 = 1 * 1  = 1
        // 2 = 1 * 2 = 2
        // 2 = 2 * 3 = 6
        // 6 = 6 * 4 = 24
        // 24 = 24 * 5 = 120
        // 120 = 120 * 6 = 720

        // 6 에서 break
        if (i > 5)
        {
            break;
        }
        
    }
    // num = 720
    printf("%d", num);
}