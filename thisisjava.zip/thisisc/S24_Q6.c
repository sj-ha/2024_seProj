#include <stdio.h>
#define N 100

int main(){
    int i = 1;
    int cnt = 0;

    // 1 ~ 100
    while (i <= N)
    {
        // 3의 배수이면서 7의 배수
        if ((i % 3) == 0 && (i % 7) == 0)
        {
            cnt++;
            // newline이 아니기 때문에 한 줄로 작성.
            printf("%d*%d*", cnt, i);
        }
        i++;
    }
    
}