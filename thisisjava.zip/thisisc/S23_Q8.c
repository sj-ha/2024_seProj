#include <stdio.h>

int main(){
    int num;
    num = 0b1001;
    //   8421 = 9
    // ob1001
    // 2진수  
    printf("%d", num);
}