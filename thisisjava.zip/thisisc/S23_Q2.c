#include <stdio.h>

int main()
{
    int a, b, c;
    a = 5 % 3;
    a--;

    b = (a++) + 3;

    printf("a: %d, b: %d\n", a, b);

    c = (++a) + 3;

    printf("a: %d, b: %d, c: %d\n", a, b, c);
}
