#include <stdio.h>

int main(){
    int calc, x = 40, y = 60, z = 80;
    //     40 < 60 true  y++ > 61
    calc = x < y ? y++ : --z;
    // 61//60//80 ?     answer: 60//61//80
    printf("%d//%d//%d", calc, y, z);
    return 0;
}