#include <stdio.h>

int main(){
    int a[5] = {3, 2, 5, 1, 4};
    int temp, i;
    // 0 ~ 3
    for ( i = 0; i < 4; i++)
    {
        // temp = 3
        temp = a[i];
        // a[0] = a[0 + 1]  a[1]
        a[i] = a[i + 1];
        // a[1 + 1] = a[2] = temp
        a[i + 1] = temp;
    }
    
    // 0 ~ 4
    for ( i = 0; i < 5; i++)
    {
        printf("%d", a[i]);
    }
    
}